import { expect, it } from "vitest";

const CSS = import.meta.glob("./settings-type.css", { query: "?raw", import: "default", eager: true }) as Record<string, string>;
const css = CSS["./settings-type.css"]!;
const declarations = [...css.matchAll(/([a-z-]+)\s*:\s*([^;}]+)[;}]/g)].map((m) => ({ prop: m[1]!, value: m[2]!.trim() }));

it("states every size, weight and colour as a token", () => {
  const sized = declarations.filter((d) => ["font-size", "font-weight", "color"].includes(d.prop));
  expect(sized.length).toBeGreaterThan(10);
  for (const d of sized) expect(d.value, `${d.prop}: ${d.value}`).toMatch(/^var\(--[a-z-]+\)$/);
});

it("only ever names a neutral text colour from the two tiers, bar a primary action's paired foreground", () => {
  for (const d of declarations.filter((x) => x.prop === "color" && x.value !== "var(--accent-fg)")) expect(d.value).toMatch(/^var\(--(text|muted)\)$/);
});

it("lets an enabled primary action keep the foreground its fill is paired with", () => {
  const rule = css.match(/\.prefs-col :is\(\.btn, \.act\)\[data-primary\]:not\(:disabled\)\s*\{([^}]*)\}/)?.[1] ?? "";
  expect(rule).toMatch(/color:\s*var\(--accent-fg\)/);
  expect(rule, "the foreground must travel with its fill, or a container without a fill rule shows light text on nothing").toMatch(/background:\s*var\(--accent\)/);
});
