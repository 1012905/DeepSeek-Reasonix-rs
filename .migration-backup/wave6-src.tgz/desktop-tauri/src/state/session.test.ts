import { describe, expect, it, vi } from "vitest";
import { chipLabel, fromHistory, initialState, reduce, type Item, type SessionEvent, type SessionState } from "./session";
import type { HistoryMessage } from "../port/port";

const run = (evs: SessionEvent[]): SessionState => evs.reduce(reduce, initialState);

describe("when this window saw the turn start", () => {
  it("is stamped by turn_started and not by a repeated start of the same message", () => {
    vi.useFakeTimers({ now: 5_000 });
    try {
      const started = run([{ kind: "turn_started", msgIndex: 3 } as SessionEvent]);
      expect(started.runSince).toBe(5_000);
      vi.setSystemTime(9_000);
      expect(reduce(started, { kind: "turn_started", msgIndex: 3 } as SessionEvent).runSince).toBe(5_000);
      expect(reduce(started, { kind: "turn_started", msgIndex: 4 } as SessionEvent).runSince).toBe(9_000);
    } finally {
      vi.useRealTimers();
    }
  });

  it("is unknown until a turn starts in this window", () => {
    expect(initialState.runSince).toBeUndefined();
    expect(run([{ kind: "text", text: "x" } as SessionEvent]).runSince).toBeUndefined();
  });
});
const tools = (s: SessionState) => s.items.filter((i): i is Extract<Item, { t: "tool" }> => i.t === "tool");
const notices = (s: SessionState) =>
  s.items.filter((i) => i.t === "notice").map((i) => (i as Extract<Item, { t: "notice" }>).text);

// The kernel shows a card the moment a call begins, before its arguments have
// finished streaming. Only the full dispatch that follows carries args.
const partial = (id: string): SessionEvent =>
  ({ kind: "tool_dispatch", tool: { id, name: "write_file", partial: true, readOnly: false } }) as SessionEvent;

const full = (id: string): SessionEvent =>
  ({
    kind: "tool_dispatch",
    tool: { id, name: "write_file", args: '{"path":"a.js"}', readOnly: false, added: 3, removed: 0 },
  }) as SessionEvent;

const result = (id: string): SessionEvent =>
  ({
    kind: "tool_result",
    tool: { id, name: "write_file", args: '{"path":"a.js"}', output: "wrote a.js", readOnly: false },
  }) as SessionEvent;

const done = (err?: string): SessionEvent => ({ kind: "turn_done", err }) as SessionEvent;

describe("sealing a turn", () => {
  it("leaves a call that ran and reported alone", () => {
    const s = run([partial("c1"), full("c1"), result("c1"), done()]);
    expect(tools(s)).toHaveLength(1);
    expect(tools(s)[0].tool.err).toBeFalsy();
    expect(notices(s)).toHaveLength(0);
  });

  // The turn was interrupted while the model was still writing the arguments:
  // nothing was dispatched, nothing ran, and no file moved. Saying each of them
  // "reported no result" claims the opposite, and one line per abandoned call
  // buries the reason the turn ended.
  it("folds calls that never started into one line", () => {
    const s = run([partial("c1"), partial("c2"), partial("c3"), done("context canceled")]);
    expect(tools(s)).toHaveLength(0);
    expect(notices(s)).toHaveLength(2);
    expect(notices(s)[0]).toContain("3 个调用");
    expect(notices(s)[1]).toBe("context canceled"); // the kernel's own words, untouched
  });

  it("keeps the old wording for a call that was dispatched and died", () => {
    const s = run([partial("c1"), full("c1"), done("context canceled")]);
    expect(tools(s)).toHaveLength(1);
    expect(tools(s)[0].tool.err).toContain("没有回报结果");
    expect(notices(s)).toHaveLength(1); // only the kernel's error
  });

  it("tells the two apart in the same batch", () => {
    const s = run([partial("c1"), full("c1"), partial("c2"), partial("c3"), done("context canceled")]);
    expect(tools(s)).toHaveLength(1);
    expect(notices(s)[0]).toContain("2 个调用");
  });

  it("reads as one call, not as a count of one", () => {
    const s = run([partial("c1"), done("context canceled")]);
    expect(notices(s)[0]).toBe("另有 1 个调用尚未开始，未修改任何文件");
  });

  // The wire omits `partial: false`, so a fold that merely spread the full
  // dispatch would leave the placeholder's flag standing and every executed
  // call would read as one that never started.
  it("clears the streaming flag once real arguments arrive", () => {
    const progress = { kind: "tool_progress", tool: { id: "c1", name: "bash", output: "…" } } as SessionEvent;
    const s = run([partial("c1"), full("c1"), progress, done("context canceled")]);
    expect(tools(s)).toHaveLength(1);
  });

  // A turn whose end never arrived is closed when the next one starts, the way
  // its own end would have closed it: the dispatched call reports, the
  // never-sent batch is counted, nothing keeps spinning.
  it("seals a lost turn's open calls when the next turn starts", () => {
    const start = { kind: "turn_started" } as SessionEvent;
    const s = run([start, partial("c1"), full("c2"), start]);
    expect(s.running).toBe(true);
    expect(tools(s).filter((i) => i.running)).toHaveLength(0);
    expect(tools(s).find((i) => i.tool.id === "c2")?.tool.err).toContain("没有回报结果");
    expect(notices(s)[0]).toContain("1 个调用");
  });

  // A rebuild mid-turn meets the record already holding the round it committed
  // — before its calls run — so the merge goes by identity, not concatenation.
  it("folds the record's copy of a call into the live card", () => {
    const start = { kind: "turn_started" } as SessionEvent;
    const live = run([start, partial("c1"), full("c1")]);
    const record = fromHistory([
      { role: "user", content: "跑一下" },
      { role: "assistant", content: "", toolCalls: [{ id: "c1", name: "bash", arguments: "{}" }] },
    ] as HistoryMessage[]);
    const s = reduce(live, { kind: "__restore", items: record.items, executions: record.executions } as SessionEvent);
    const cards = tools(s).filter((i) => i.tool.id === "c1");
    expect(cards).toHaveLength(1);
    expect(cards[0].running).toBe(true);
    expect(cards[0].tool.args).toBe('{"path":"a.js"}');
    const settled = reduce(s, result("c1"));
    expect(tools(settled)).toHaveLength(1);
    expect(tools(settled)[0].tool.output).toBe("wrote a.js");
  });

  // A result the record already holds is the truth; the live copy adds nothing.
  it("adopts the record's settled call over the live one", () => {
    const start = { kind: "turn_started" } as SessionEvent;
    const live = run([start, partial("c1"), full("c1")]);
    const record = fromHistory([
      { role: "user", content: "跑一下" },
      { role: "assistant", content: "", toolCalls: [{ id: "c1", name: "bash", arguments: "{}" }] },
      { role: "tool", content: "wrote a.js", toolCallId: "c1", toolName: "bash" },
    ] as HistoryMessage[]);
    const s = reduce(live, { kind: "__restore", items: record.items, executions: record.executions } as SessionEvent);
    expect(tools(s)).toHaveLength(1);
    expect(tools(s)[0].running).toBe(false);
    expect(tools(s)[0].tool.output).toBe("wrote a.js");
  });

  // The record holds the committed answer, but the kernel commits each
  // text-only round BEFORE handleFinalResponse decides whether the turn
  // continues — the baseline-criteria run, the executor-handoff nudge, the
  // empty-final retry and the steer drain all do — so a record ending on a
  // say proves the answer, not the end.
  it("keeps a live turn running when the record already holds its answer", () => {
    const start = { kind: "turn_started", msgIndex: 1 } as SessionEvent;
    const live = run([start, { kind: "text", text: "你好，正在" } as SessionEvent]);
    const record = fromHistory([
      { role: "user", content: "问" },
      { role: "assistant", content: "你好，这是完整回答" },
    ] as HistoryMessage[]);
    const s = reduce(live, { kind: "__restore", items: record.items, executions: record.executions } as SessionEvent);
    expect(s.items.filter((i) => i.t === "say")).toHaveLength(1);
    expect(s.running).toBe(true);
  });

  // /history carries no turn-end marker, so the typed fact that a turn is
  // over rides the status read every restore already pairs with the record.
  // The record cannot even name the case it misses: a turn_done lost outside
  // the replay window leaves the live cards spinning over a record whose last
  // word is a tool result.
  it("clears a stale running flag when the kernel says the turn is over", () => {
    const start = { kind: "turn_started", msgIndex: 1 } as SessionEvent;
    const live = run([start, partial("c1"), full("c1")]);
    const record = fromHistory([
      { role: "user", content: "跑一下" },
      { role: "assistant", content: "", toolCalls: [{ id: "c1", name: "bash", arguments: "{}" }] },
      { role: "tool", content: "wrote a.js", toolCallId: "c1", toolName: "bash" },
    ] as HistoryMessage[]);
    const restored = reduce(live, { kind: "__restore", items: record.items, executions: record.executions } as SessionEvent);
    expect(restored.running).toBe(true);
    const s = reduce(restored, { kind: "__running", running: false } as SessionEvent);
    expect(s.running).toBe(false);
  });

  // What the record does not speak for is happening, not history: it stays
  // after the record, where the next delta lands on the card it was landing on.
  it("keeps the running tail the record does not speak for", () => {
    const live = run([{ kind: "turn_started" } as SessionEvent, partial("c1"), full("c2")]);
    const s = reduce(live, { kind: "__restore", items: [{ t: "user", id: "h1", text: "a" }], executions: {} } as SessionEvent);
    expect(s.items[0]).toMatchObject({ t: "user", text: "a" });
    expect(tools(s).map((i) => i.tool.id)).toEqual(["c1", "c2"]);
    expect(tools(s).every((i) => i.running)).toBe(true);
    expect(s.running).toBe(true);
  });

  // A resumed reader's watermark can land before this turn's open, and the
  // replay delivers the same turn_started twice. The second names the turn
  // already in front of us: not a lost end, so nothing it opened has ended —
  // the call is still running and the prompt is still owed an answer.
  it("does not seal a turn whose start frame arrives twice", () => {
    const start = { kind: "turn_started", msgIndex: 1 } as SessionEvent;
    const approval = {
      kind: "approval_request",
      approval: { id: "apv-1", tool: "write_file", subject: "src/main.rs" },
    } as SessionEvent;
    const s = run([start, partial("c1"), full("c1"), approval, start]);
    expect(s.running).toBe(true);
    expect(tools(s)).toHaveLength(1);
    expect(tools(s)[0].running).toBe(true);
    expect(tools(s)[0].tool.err).toBeFalsy();
    expect(s.items.filter((i) => i.t === "approval")).toHaveLength(1);
    expect(notices(s)).toHaveLength(0);
  });

  // The seal exists for the turn whose end never arrived, and identity is
  // what tells that apart: the next start names the next message.
  it("seals the lost turn when the next start names another message", () => {
    const s = run([
      { kind: "turn_started", msgIndex: 1 } as SessionEvent,
      partial("c1"),
      full("c1"),
      { kind: "turn_started", msgIndex: 2 } as SessionEvent,
    ]);
    expect(tools(s).filter((i) => i.running)).toHaveLength(0);
    expect(tools(s)[0].tool.err).toContain("没有回报结果");
  });
});

// The kernel flags a turn the user's own action ended. Its err is the sentinel's
// wording, which says nothing the flag does not, so it is not a failure card.
describe("a turn the user cancelled", () => {
  it("does not draw the cancellation as an error card", () => {
    const s = run([partial("c1"), { kind: "turn_done", cancelled: true, err: "context canceled" } as SessionEvent]);
    expect(s.items.filter((i) => i.t === "notice" && i.level === "error")).toHaveLength(0);
    expect(s.terminal).toEqual({ kind: "cancelled" });
    expect(s.doing).toBe("common.cancelled");
  });

  it("still draws a genuine failure", () => {
    const s = run([{ kind: "turn_done", err: "provider down" } as SessionEvent]);
    expect(notices(s)).toEqual(["provider down"]);
  });
});

describe("rebuilding a reopened transcript", () => {
  const users = (msgs: HistoryMessage[]) =>
    fromHistory(msgs).items.filter((i): i is Extract<Item, { t: "user" }> => i.t === "user");

  // The control blocks come off before the transcript sees a turn. A turn sent
  // as a dropped file and nothing else still has the "@path" it was referenced
  // by, and keeping that row is how a message that was on screen while you sent
  // it is still there the next time the window opens.
  it("keeps a turn that was an attachment reference and no words", () => {
    const got = users([
      { role: "user", content: "@.reasonix/attachments/clipboard-1.png" },
      { role: "assistant", content: "看到了" },
    ]);
    expect(got).toHaveLength(1);
    expect(got[0].text).toBe("@.reasonix/attachments/clipboard-1.png");
  });

  it("still drops a row that is neither text nor attachment", () => {
    expect(users([{ role: "user", content: "<reasoning-language>zh</reasoning-language>" }])).toHaveLength(0);
  });

  it("strips a failed-MCP-prompt block from a replayed turn", () => {
    const got = users([
      { role: "user", content: "<mcp-prompt-failure>\nThe user invoked MCP prompt \"p\"\n</mcp-prompt-failure>\n你好" },
    ]);
    expect(got).toHaveLength(1);
    expect(got[0].text).toBe("你好");
  });

  it("strips a refused-calls block from a replayed turn", () => {
    const got = users([
      { role: "user", content: "<refused-calls>\nThe host refused these tool calls\n- bash {\"command\":\"git push\"} (permission.deny_rule)\n</refused-calls>\n继续" },
    ]);
    expect(got).toHaveLength(1);
    expect(got[0].text).toBe("继续");
  });

  it("strips a session-scratch block from a replayed turn", () => {
    const got = users([
      { role: "user", content: "<session-scratch>\nThis session has a private scratch directory, $TMPDIR.\n</session-scratch>\n继续" },
    ]);
    expect(got).toHaveLength(1);
    expect(got[0].text).toBe("继续");
  });

  it("leaves an ordinary turn as its text", () => {
    const got = users([{ role: "user", content: "第一句话" }]);
    expect(got).toHaveLength(1);
    expect(got[0].text).toBe("第一句话");
  });
});

describe("the turn's quality summary", () => {
  it("stays out of the transcript", () => {
    const s = run([{ kind: "completion_summary", completion: { verdict: "partial", mutations: 2 } } as SessionEvent]);
    expect(s.items).toHaveLength(0);
  });
});

describe("a notice about the runtime rather than the conversation", () => {
  const notice = (audience: string | undefined, level: string, text: string): SessionEvent =>
    ({ kind: "notice", audience, level, text }) as SessionEvent;

  // The transcript is the record of a conversation. "guardian enabled ·
  // model=deepseek-v4-pro" was the first row of a session nobody had spoken in
  // yet — a fact about the assembly, rendered with the weight of a turn.
  it("keeps an assembly fact out of the transcript", () => {
    const s = run([notice("operator", "info", "guardian enabled · model=x")]);
    expect(notices(s)).toEqual([]);
    expect(s.runtime).toEqual([]);
  });

  // Dropping it entirely would trade one bug for another. A warning is the
  // runtime saying something is wrong with itself, and that has to be seen —
  // just not as something someone said.
  it("gives a runtime warning its own place, not a transcript card", () => {
    const s = run([notice("operator", "warn", "An MCP server failed to start.")]);
    expect(notices(s)).toEqual([]);
    expect(s.runtime.map((n) => n.text)).toEqual(["An MCP server failed to start."]);
  });

  it("lets a runtime warning be dismissed", () => {
    const s = run([notice("operator", "warn", "An MCP server failed to start.")]);
    const gone = reduce(s, { kind: "__runtime_seen", id: s.runtime[0].id } as SessionEvent);
    expect(gone.runtime).toEqual([]);
  });

  // Everything else is still about the conversation and still belongs in it:
  // a permission that was saved, a rewind that was undone, a plan awaiting
  // approval all answer something the user just did.
  it("leaves a conversation notice where it was", () => {
    const s = run([notice(undefined, "info", "undid last rewind")]);
    expect(notices(s)).toEqual(["undid last rewind"]);
    expect(s.runtime).toEqual([]);
  });

  it("carries a skipped-extension notice with its code and payload, once per extension", () => {
    const skipped = (extension: string) => ({
      kind: "notice", audience: "operator", level: "warn", code: "extension_skipped", text: "skipped",
      detail: JSON.stringify({ extension, point: "tool.before", reason: "no_live_sidecar" }),
    }) as SessionEvent;
    const s = run([skipped("a"), skipped("a"), skipped("b")]);
    expect(notices(s)).toEqual([]);
    expect(s.runtime.map((n) => n.code)).toEqual(["extension_skipped", "extension_skipped"]);
    expect(s.runtime.map((n) => JSON.parse(n.detail ?? "{}").extension)).toEqual(["a", "b"]);
  });

  it("keeps legacy capability proxy audits out of the transcript", () => {
    const s = run([notice(undefined, "info", "capability proxy: use_capability → web_fetch")]);
    expect(notices(s)).toEqual([]);
  });
});

describe("a line that is still queued", () => {
  const typed = (id: string, text: string): SessionEvent =>
    ({ kind: "__user", text, pending: true, id }) as SessionEvent;
  const rows = (st: SessionState) => st.items.filter((i): i is Extract<Item, { t: "user" }> => i.t === "user");
  const queued = (id: string, itemId: string, kind: "steer" | "followup"): SessionEvent =>
    ({ kind: "__queued", id, itemId, queued: kind }) as SessionEvent;

  it("raises one held-queue notice per window, and only for a paused receipt", () => {
    const held = (id: string, itemId: string): SessionEvent =>
      ({ kind: "__queued", id, itemId, queued: "followup", paused: true }) as SessionEvent;
    const plain = run([typed("row-1", "a"), queued("row-1", "inbox-1", "steer")]);
    expect(plain.runtime).toEqual([]);
    const st = run([typed("row-1", "a"), held("row-1", "inbox-1"), typed("row-2", "b"), held("row-2", "inbox-2")]);
    expect(st.runtime.map((n) => n.code)).toEqual(["queue_paused_hold"]);
    const gone = run([typed("row-1", "a"), held("row-1", "inbox-1")]);
    const after = reduce(reduce(gone, { kind: "__runtime_seen", id: gone.runtime[0].id } as SessionEvent), held("row-1", "inbox-1"));
    expect(after.runtime).toHaveLength(1);
  });

  // The row is on screen before the kernel has answered. The receipt is what
  // gives it a name to be taken back by, and without it the card has a button
  // it cannot press.
  it("remembers the queue id the kernel answered with", () => {
    const st = run([typed("row-1", "密码我告诉你"), queued("row-1", "inbox-9", "steer")]);
    expect(rows(st)[0].itemId).toBe("inbox-9");
    expect(rows(st)[0].pending).toBe(true);
  });

  // A whole turn refused because one is already running is queued too, and the
  // row has to say which wait it is in: the two land at different moments.
  it("marks a follow-up queued even though it was sent as a turn", () => {
    const sent = ({ kind: "__user", text: "x", pending: false, id: "row-2" }) as SessionEvent;
    const st = run([sent, queued("row-2", "inbox-10", "followup")]);
    expect(rows(st)[0].pending).toBe(true);
    expect(rows(st)[0].queued).toBe("followup");
  });

  // The kernel holds the line for a retry and says so; the queue panel shows it
  // as blocked. The transcript row must not keep calling itself queued.
  it("drops the pending row of a line the kernel could not apply, and keeps the notice", () => {
    const waiting = run([typed("row-1", "x"), queued("row-1", "inbox-9", "steer"), typed("row-2", "y"), queued("row-2", "inbox-10", "steer")]);
    const st = reduce(waiting, { kind: "notice", code: "unapplied_steer", level: "warn", text: "not applied", itemId: "inbox-9" } as SessionEvent);
    expect(rows(st).map((r) => r.itemId)).toEqual(["inbox-10"]);
    expect(st.items.some((i) => i.t === "notice" && i.code === "unapplied_steer")).toBe(true);
  });

  it("leaves a delivered line alone when a notice names it", () => {
    const waiting = run([typed("row-1", "x"), queued("row-1", "inbox-9", "steer")]);
    const read = reduce(waiting, { kind: "steer", text: "x", itemId: "inbox-9" } as SessionEvent);
    const st = reduce(read, { kind: "notice", code: "unapplied_steer", level: "warn", text: "late", itemId: "inbox-9" } as SessionEvent);
    expect(rows(st)).toHaveLength(1);
    expect(rows(st)[0]).toMatchObject({ pending: false, steer: true });
  });

  it("does not name a row for an entry taken back before its receipt landed", () => {
    const st = run([typed("row-1", "x"), { kind: "__unsent", id: "inbox-9" } as SessionEvent, queued("row-1", "inbox-9", "steer")]);
    expect(rows(st)).toEqual([]);
  });

  it("takes the row away once the kernel drops it", () => {
    const waiting = run([typed("row-1", "x"), queued("row-1", "inbox-9", "steer")]);
    expect(rows(reduce(waiting, { kind: "__unsent", id: "row-1" } as SessionEvent))).toEqual([]);
  });

  // Too late is not an error state on the row: the steer event that made it too
  // late is the same one that stops it calling itself queued.
  it("stops calling itself queued when the turn reads it", () => {
    const waiting = run([typed("row-1", "x"), queued("row-1", "inbox-9", "steer")]);
    const read = reduce(waiting, { kind: "steer", text: "x" } as SessionEvent);
    expect(rows(read)[0].pending).toBe(false);
  });

  // Its seat was booked when it was typed, which is not when it happened. Every
  // sentence and tool call that ran during the wait would otherwise sort after
  // a line the model had not yet read.
  it("seats the row where the turn read it, not where it was typed", () => {
    const waiting = run([typed("row-1", "later"), queued("row-1", "inbox-9", "steer")]);
    const worked = reduce(waiting, { kind: "text", text: "meanwhile" } as SessionEvent);
    const read = reduce(worked, { kind: "steer", text: "later", itemId: "inbox-9" } as SessionEvent);
    expect(read.items[read.items.length - 1]).toMatchObject({ t: "user", text: "later", pending: false });
  });

  // The same rule for the other wait: a follow-up is a turn of its own, so its
  // row belongs at the turn the kernel started for it.
  it("seats a follow-up where its turn began", () => {
    const sent = ({ kind: "__user", text: "next", pending: false, id: "row-2" }) as SessionEvent;
    const waiting = run([sent, queued("row-2", "inbox-10", "followup")]);
    const worked = reduce(waiting, { kind: "text", text: "meanwhile" } as SessionEvent);
    const begun = reduce(worked, { kind: "turn_started", authoredTurn: 4, msgIndex: 9 } as SessionEvent);
    expect(begun.items[begun.items.length - 1]).toMatchObject({ t: "user", text: "next", pending: false, authoredTurn: 4 });
  });
});

describe("waiting for another session to finish writing", () => {
  const lease = (code: string, level: string, text: string): SessionEvent =>
    ({ kind: "notice", code, level, text }) as SessionEvent;
  const cards = (st: SessionState) => st.items.filter((i): i is Extract<Item, { t: "notice" }> => i.t === "notice");

  it("preserves holder and claim scope through close and event replay", () => {
    const scope = { contended: 0, heldMs: 0, idleMs: 0, holder: "Fixture A", holderSessionId: "session-a", paths: ["src/a.go"], requestedPaths: ["src/a.go"] };
    const opened = { ...lease("workspace_lease", "warn", "Waiting"), workspaceLease: scope } as SessionEvent;
    const closed = { ...lease("workspace_lease_resumed", "info", "Claim granted"), workspaceLease: scope } as SessionEvent;
    const waiting = run([opened]);
    expect(cards(waiting)[0]).toMatchObject({ workspaceLease: scope });
    const done = reduce(waiting, closed);
    expect(cards(done)).toHaveLength(1);
    expect(cards(done)[0]).toMatchObject({ id: cards(waiting)[0].id, workspaceLease: scope });
    expect(cards(run([opened, closed]))[0]).toMatchObject({ workspaceLease: scope });
    expect(cards(reduce(waiting, { ...closed, code: "workspace_lease_abandoned" } as SessionEvent))[0]).toMatchObject({ workspaceLease: scope });
  });

  // The open used to be the whole surface: one card saying the session would
  // continue "when it is safe", still saying it long after it had.
  it("rewrites the waiting card in place when the wait ends", () => {
    const st = run([
      lease("workspace_lease", "warn", "Another session is writing to this workspace."),
      lease("workspace_lease_resumed", "info", "The workspace is free again; this session has continued."),
    ]);
    expect(cards(st)).toHaveLength(1);
    expect(cards(st)[0].code).toBe("workspace_lease_resumed");
    expect(cards(st)[0].level).toBe("info");
  });

  // A wait is a state, and the strip is where this interface says what a turn
  // is stopped on — the same place 等你批准 goes.
  it("says what the turn is waiting on, and stops saying it when it is not", () => {
    const waiting = run([lease("workspace_lease", "warn", "Another session is writing to this workspace.")]);
    expect(waiting.doing).toBe("app.waiting_for_the_workspace");
    const gaveUp = reduce(waiting, lease("workspace_lease_abandoned", "info", "The wait ended."));
    expect(gaveUp.doing).toBe("common.running");
    expect(cards(gaveUp)).toHaveLength(1);
  });
});

describe("repeated unclassified notices", () => {
  it("folds consecutive identical text from an older journal", () => {
    const event = { kind: "notice", level: "warn", text: "input was not accepted: this session is no longer writable — reopen it and try again" } as SessionEvent;
    const st = run([event, event, event]);
    const cards = st.items.filter((i): i is Extract<Item, { t: "notice" }> => i.t === "notice");
    expect(cards).toHaveLength(1);
    expect(cards[0].count).toBe(3);
  });
});

// Nothing on the wire echoes what the user typed, so the row is the client's
// to add — and its to take back when the line never left. Reporting the
// refusal alone would leave a turn on screen that never happened.
describe("a line the kernel refused", () => {
  const typed = (id: string, text: string): SessionEvent =>
    ({ kind: "__user", text, pending: false, id }) as SessionEvent;
  const users = (s: SessionState) =>
    s.items.filter((i) => i.t === "user").map((i) => (i as Extract<Item, { t: "user" }>).text);

  it("leaves the transcript", () => {
    const s = run([typed("u1", "first"), typed("u2", "second"), { kind: "__unsent", id: "u2" } as SessionEvent]);
    expect(users(s)).toEqual(["first"]);
  });

  it("takes back only its own row", () => {
    const s = run([typed("u1", "kept"), { kind: "__unsent", id: "nothing-by-that-name" } as SessionEvent]);
    expect(users(s)).toEqual(["kept"]);
  });
});

// The kernel emits Retrying before each backoff sleep and leaves it to the
// window to take the line down again: whatever comes back next is the proof the
// connection recovered, and it is far more often a tool call than a sentence.
describe("the retry line", () => {
  const started = (): SessionEvent => ({ kind: "turn_started" }) as SessionEvent;
  const retrying = (attempt: number, scope?: string): SessionEvent =>
    ({ kind: "retrying", retryAttempt: attempt, retryMax: 5, retryScope: scope }) as SessionEvent;

  it("comes down on the first packet of any kind, not only on text", () => {
    const s = run([started(), retrying(1, "stream"), partial("c1")]);
    expect(s.waiting).toEqual({});
  });

  it("stays up while nothing has come back", () => {
    const s = run([started(), retrying(1, "stream"), { kind: "notice", text: "x" } as SessionEvent]);
    expect(s.waiting.retry).toMatchObject({ attempt: 1, max: 5, scope: "stream" });
  });

  // Only the kernel knows whether it never got a header or lost a body it was
  // already writing out, and the two say different things to the reader.
  it("carries the kernel's own answer for which half broke", () => {
    const s = run([started(), retrying(2, "headers")]);
    expect(s.waiting.retry?.scope).toBe("headers");
  });

  it("shows a stall that starts between two steps", () => {
    const s = run([started(), { kind: "text", text: "hi" } as SessionEvent, retrying(1, "headers")]);
    expect(s.waiting.ttftSince).toBeTruthy();
    expect(s.waiting.retry?.attempt).toBe(1);
  });

  // The notice fires when an attempt fails, so the clock it starts is the next
  // attempt's wait: a counter that carried over would claim the whole stall as
  // one wait.
  it("restarts the clock for each attempt", () => {
    vi.useFakeTimers();
    try {
      vi.setSystemTime(1000);
      const first = run([started(), retrying(1, "headers")]);
      vi.setSystemTime(61_000);
      const second = reduce(first, retrying(2, "headers"));
      expect(first.waiting.retry?.since).toBe(1000);
      expect(second.waiting.retry?.since).toBe(61_000);
    } finally {
      vi.useRealTimers();
    }
  });

  it("carries the failure class, backoff and answer bound the kernel sent", () => {
    const s = run([
      started(),
      {
        kind: "retrying",
        retryAttempt: 1,
        retryMax: 10,
        retryScope: "headers",
        retryCause: "upstream_status",
        retryStatus: 502,
        retryDelayMs: 1250,
        retryTimeoutSecs: 300,
      } as SessionEvent,
    ]);
    expect(s.waiting.retry).toMatchObject({ cause: "upstream_status", status: 502, delayMs: 1250, timeoutSecs: 300 });
  });

  it("leaves the class unset for a kernel that does not send one", () => {
    const s = run([started(), retrying(1, "headers")]);
    expect(s.waiting.retry?.cause).toBeUndefined();
    expect(s.waiting.retry?.delayMs).toBeUndefined();
  });

  it("comes down when the turn ends", () => {
    const s = run([started(), retrying(1, "headers"), done()]);
    expect(s.waiting).toEqual({});
  });
});

// The kernel holds the run open on an unanswered question and re-emits it to
// every client that attaches, precisely so a reconnected window can answer it.
// The transcript rebuild then overwrote the items wholesale — and a question is
// not in the transcript, it is the run stopped waiting on one. The session sat
// at 等你决定 with nothing on screen to decide, and the queued turn behind it
// never dispatched.
describe("a question the run is still blocked on", () => {
  const asking = (id: string): SessionEvent =>
    ({
      kind: "ask_request",
      ask: { id, questions: [{ id: "q1", prompt: "GUI 框架？", options: [{ label: "egui 0.27" }] }] },
    }) as SessionEvent;
  const approving = (id: string): SessionEvent =>
    ({ kind: "approval_request", approval: { id, tool: "write_file", subject: "src/main.rs" } }) as SessionEvent;
  const rebuild = (items: Item[] = []): SessionEvent => ({ kind: "__restore", items, plan: [], executions: {} }) as SessionEvent;
  const asks = (s: SessionState) => s.items.filter((i): i is Extract<Item, { t: "ask" }> => i.t === "ask");
  const said = (text: string): Item => ({ t: "say", id: "h1", text, reasoning: undefined, done: true }) as Item;

  it("survives the rebuild that follows a reconnect", () => {
    const s = run([asking("ask-1"), rebuild([said("有一个技术决策需要确认：")])]);
    expect(s.doing, "the header says the run is waiting on you").toBe("app.waiting_for_your_answer");
    expect(asks(s), "so the question has to still be answerable").toHaveLength(1);
    expect(asks(s)[0].ask.id).toBe("ask-1");
  });

  it("drops a cancelled ask before a rewritten user turn is restored and sent", () => {
    const cancelled = reduce(run([asking("ask-1")]), {
      kind: "turn_done", cancelled: true, err: "context canceled",
    } as SessionEvent);
    const rewritten = reduce(reduce(cancelled, rebuild([said("Earlier answer")])),
      { kind: "__user", id: "edited", text: "Rewritten question", pending: false } as SessionEvent);
    expect(rewritten.items.map((i) => i.t)).toEqual(["say", "user"]);
    expect(asks(rewritten)).toHaveLength(0);
  });

  it("removes pending prompts at turn end but keeps answered questions", () => {
    const first = run([asking("answered"), asking("pending"), approving("approval")]);
    const answered = reduce(first, {
      kind: "__decided", id: asks(first)[0].id, answers: [["egui 0.27"]],
    } as SessionEvent);
    const ended = reduce(answered, { kind: "turn_done", cancelled: true } as SessionEvent);
    expect(asks(ended).map((i) => [i.ask.id, i.answered])).toEqual([["answered", [["egui 0.27"]]]]);
    expect(ended.items.some((i) => i.t === "approval")).toBe(false);
  });

  it("keeps an approval the same way, for the same reason", () => {
    const s = run([approving("apv-1"), rebuild([said("先写文件")])]);
    expect(s.items.filter((i) => i.t === "approval")).toHaveLength(1);
  });

  // The record is what a rebuild is for: what the rebuild brought back stays
  // where the kernel put it, and the open prompt lands after it.
  it("puts the rebuilt record back, with the question after it", () => {
    const s = run([asking("ask-1"), rebuild([said("一"), said("二")])]);
    expect(s.items.map((i) => i.t)).toEqual(["say", "say", "ask"]);
  });

  it("does not resurrect one that was already answered", () => {
    const first = run([asking("ask-1")]);
    const answered = reduce(first, { kind: "__decided", id: asks(first)[0].id, answers: [["egui 0.27"]] } as SessionEvent);
    const s = reduce(answered, rebuild([said("决定了")]));
    expect(asks(s), "an answered question belongs to the record, not to the wait").toHaveLength(0);
  });

  // EventSource reconnects on its own and the kernel replays the pending prompt
  // to whoever attaches, so the same question arrives more than once. Two cards
  // for one question are two answers the kernel will not both accept.
  it("shows one card per question however many times it is replayed", () => {
    const s = run([asking("ask-1"), asking("ask-1")]);
    expect(asks(s)).toHaveLength(1);
  });

  it("tells two different questions apart", () => {
    const s = run([asking("ask-1"), asking("ask-2")]);
    expect(asks(s)).toHaveLength(2);
  });

  // What seals a card the user did not click is the decision the kernel
  // recorded, which arrives on the same ordered stream as the request. It used
  // to be the /status projection, polled four times a second: a snapshot taken
  // before the prompt existed omits it exactly as a resolved one does, so a
  // card could be sealed within 250ms of arriving while the run stayed blocked
  // on it — buttons gone, and the line underneath claiming it was allowed.
  const receipt = (id: string, outcome: string): SessionEvent =>
    ({ kind: "notice", code: "decision_receipt", decisionReceipt: { id, kind: "tool", outcome } }) as SessionEvent;
  const answerable = (s: SessionState) =>
    s.items.filter((i): i is Extract<Item, { t: "approval" }> => i.t === "approval" && i.verdict === undefined);

  it("stays answerable until a decision is actually recorded", () => {
    const s = run([approving("apv-1"), approving("apv-2")]);
    expect(answerable(s).map((i) => i.a.id)).toEqual(["apv-1", "apv-2"]);
  });

  it("seals the one the receipt names, with what was decided", () => {
    const s = run([approving("apv-1"), approving("apv-2"), receipt("apv-1", "deny")]);
    expect(answerable(s).map((i) => i.a.id)).toEqual(["apv-2"]);
    const sealed = s.items.find((i) => i.t === "approval" && i.a.id === "apv-1") as Extract<Item, { t: "approval" }>;
    expect(sealed.verdict, "the outcome the kernel recorded, not a guess").toBe("deny");
    expect(s.items.some((i) => i.t === "notice"), "the audit receipt is not a chat message").toBe(false);
  });

  it("does not guess that a new receipt outcome was allowed", () => {
    const s = run([approving("apv-1"), receipt("apv-1", "future_outcome")]);
    expect((s.items[0] as Extract<Item, { t: "approval" }>).verdict).toBe("unknown");
  });

  it("does not present another window's answer as an unanswered question", () => {
    const s = run([asking("ask-1"), receipt("ask-1", "answered")]);
    const ask = s.items[0] as Extract<Item, { t: "ask" }>;
    expect(ask.answeredElsewhere).toBe(true);
    expect(ask.answered).toEqual([]);
  });

  // The receipt for the click this window made arrives right behind it. It must
  // not reopen or relabel a card the user already watched settle.
  it("leaves a card this window already sealed alone", () => {
    const clicked = run([approving("apv-1")]);
    const local = reduce(clicked, { kind: "__decided", id: clicked.items[0].id, verdict: "always" } as SessionEvent);
    const s = reduce(local, receipt("apv-1", "allow_session"));
    expect((s.items[0] as Extract<Item, { t: "approval" }>).verdict).toBe("always");
  });

  // The receipt can also overtake the answer's own reply. The card then reads
  // what this window sent, not "handled in another window".
  it("keeps this window's answer when the receipt overtook it", () => {
    const racing = run([asking("ask-1"), receipt("ask-1", "answered")]);
    const s = reduce(racing, { kind: "__decided", id: racing.items[0].id, answers: [["B"]] } as SessionEvent);
    const ask = s.items[0] as Extract<Item, { t: "ask" }>;
    expect(ask.answeredElsewhere).toBe(false);
    expect(ask.answered).toEqual([["B"]]);
  });
});

// A session's coverage is the kernel's answer, not this side's running guess:
// the record is not replayed on restore, so the fold has folded nothing yet.
describe("restoring what a session has been billed", () => {
  const totals = (over: Partial<Extract<SessionEvent, { kind: "__totals" }>> = {}): SessionEvent =>
    ({ kind: "__totals", hit: 10, miss: 5, cost: 0.02, currency: "CNY", ...over }) as SessionEvent;

  it("takes the coverage the kernel holds every round for", () => {
    const s = reduce(initialState, totals({ coverage: "partial", incompleteReason: "no_price" }));
    expect(s.metrics.coverage).toBe("partial");
    expect(s.metrics.incompleteReason).toBe("no_price");
    expect(s.metrics.cost).toEqual([{ currency: "CNY", amount: 0.02 }]);
  });

  // Replaced rather than joined, for the same reason the totals are: the read
  // belongs to whichever session this pane now holds.
  it("replaces what a previously held session had folded", () => {
    const held = reduce(initialState, totals({ coverage: "partial", incompleteReason: "no_price" }));
    const switched = reduce(held, totals({ coverage: "complete" }));
    expect(switched.metrics.coverage).toBe("complete");
    expect(switched.metrics.incompleteReason, "the reason belonged to the other session").toBe("");
  });

  // A kernel older than the field restores nothing rather than a guess: the
  // live fold takes over from the next round, which is all it can speak for.
  it("restores no coverage from a kernel that cannot say", () => {
    const s = reduce(initialState, totals({ coverage: undefined }));
    expect(s.metrics.coverage).toBe("none");
    expect(s.metrics.cost).toEqual([{ currency: "CNY", amount: 0.02 }]);
  });
});

// A turn can run one model and hand part of it to another. Without the turn's
// own name on its replies, a reader has only the composer's current setting,
// which is a different fact and moves on its own.
describe("which model wrote a reply", () => {
  const says = (st: SessionState) => st.items.filter((i): i is Extract<Item, { t: "say" }> => i.t === "say");

  it("names the turn's model on the replies inside it", () => {
    const st = run([
      { kind: "turn_started", authoredTurn: 1, msgIndex: 0, modelRef: "yyds/claude-opus-4.8" },
      { kind: "text", text: "on it" },
    ] as SessionEvent[]);
    expect(says(st)[0].model).toBe("yyds/claude-opus-4.8");
  });

  // The second model names itself, and must not be recorded as the turn's.
  it("keeps a second model's own name on what it wrote", () => {
    const st = run([
      { kind: "turn_started", authoredTurn: 1, msgIndex: 0, modelRef: "yyds/claude-opus-4.8" },
      { kind: "text", text: "planning", source: "planner", modelRef: "deepseek/deepseek-pro" },
    ] as SessionEvent[]);
    expect(says(st)[0].model).toBe("deepseek/deepseek-pro");
  });
});

describe("a receipt that arrives after the delivery it is for", () => {
  const sent = { kind: "__user", text: "换个思路", pending: true, id: "row-1" } as SessionEvent;
  const delivered = { kind: "steer", text: "换个思路", itemId: "it1" } as SessionEvent;
  const receipt = { kind: "__queued", id: "row-1", itemId: "it1", queued: "steer" } as SessionEvent;
  const users = (st: SessionState) => st.items.filter((i): i is Extract<Item, { t: "user" }> => i.t === "user");

  it("leaves one delivered line and nothing waiting", () => {
    const rows = users(run([sent, delivered, receipt]));
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ steer: true, itemId: "it1" });
    expect(rows.some((r) => r.pending)).toBe(false);
  });

  it("still names a line the kernel has not delivered yet", () => {
    expect(users(run([sent, receipt]))[0]).toMatchObject({ pending: true, itemId: "it1" });
  });
});

describe("chipLabel", () => {
  it("says the turn is running for a client that joined after turn_started", () => {
    expect(chipLabel(initialState, true)).toBe("common.running");
    const done = run([{ kind: "turn_started" } as SessionEvent, { kind: "turn_done" } as SessionEvent]);
    expect(chipLabel(done, true)).toBe("common.running");
  });

  it("keeps what the stream says once it has said something", () => {
    const s = reduce(initialState, { kind: "tool_dispatch", tool: { id: "t1", name: "bash" } } as SessionEvent);
    expect(chipLabel(s, true)).toBe("bash");
  });

  it("leaves a settled turn and a live one alone", () => {
    expect(chipLabel(initialState, false)).toBe("app.idle");
    const live = run([{ kind: "turn_started" } as SessionEvent]);
    expect(chipLabel(live, true)).toBe(live.doing);
  });
});

describe("compaction digest restart", () => {
  const progress = (text?: string): SessionEvent => ({ kind: "compaction_progress", text }) as SessionEvent;
  const summaryOf = (s: SessionState) => (s.items.find((i) => i.t === "compaction") as Extract<Item, { t: "compaction" }>).c.summary;

  it("keeps only the retried attempt's text when the first was cut", () => {
    const s = run([
      { kind: "compaction_started", compaction: {} } as SessionEvent,
      progress("## Goal\ncut off mid"),
      progress(),
      progress("## Goal\nsecond"),
    ]);
    expect(summaryOf(s)).toBe("## Goal\nsecond");
  });

  it("shows nothing from the cut attempt if the retry writes nothing", () => {
    const s = run([{ kind: "compaction_started", compaction: {} } as SessionEvent, progress("cut"), progress()]);
    expect(summaryOf(s)).toBe("");
  });

});

describe("an ask the host skipped on timeout", () => {
  it("is sealed by its receipt as timed out, not as answered elsewhere by someone", () => {
    const asked = run([
      { kind: "turn_started" } as SessionEvent,
      { kind: "ask_request", ask: { id: "a1", questions: [{ id: "q1", header: "H", prompt: "Which?", options: [{ label: "A" }, { label: "B" }] }] } } as SessionEvent,
    ]);
    const sealed = reduce(asked, { kind: "notice", decisionReceipt: { id: "a1", kind: "ask", outcome: "timed_out", subject: "Which?: —" } } as SessionEvent);
    const ask = sealed.items.find((i) => i.t === "ask") as Extract<Item, { t: "ask" }>;
    expect(ask.timedOut).toBe(true);
    expect(ask.answered).toEqual([]);
  });
});

// The kernel's progress frame carries the call id and the newest chunk only, so
// folding it like a dispatch would blank the call's name and keep one chunk.
describe("a running call's live output", () => {
  const chunk = (output: string) => ({ kind: "tool_progress", tool: { id: "c1", name: "", output } }) as SessionEvent;

  it("keeps the call's name and adds each chunk to what came before", () => {
    const s = run([full("c1"), chunk("step 1\n"), chunk("step 2\n")]);
    expect(tools(s)).toHaveLength(1);
    expect(tools(s)[0].tool.name).toBe("write_file");
    expect(tools(s)[0].tool.output).toBe("step 1\nstep 2\n");
    expect(tools(s)[0].running).toBe(true);
  });

  it("gives way to the final result", () => {
    const s = run([full("c1"), chunk("step 1\n"), { kind: "tool_result", tool: { id: "c1", name: "bash", output: "all done" } } as SessionEvent]);
    expect(tools(s)[0].tool.output).toBe("all done");
  });
});

// An error a read raised goes away when the same read next succeeds; one a
// person's action raised, or another source's, stays until they dismiss it.
describe("an error that names where it came from", () => {
  it("is cleared by a later success of that same source only", () => {
    const failed = run([{ kind: "__error", text: "status unreadable", from: "status" }]);
    expect(failed.error).toBe("status unreadable");
    expect(reduce(failed, { kind: "__error_clear", from: "extension" }).error).toBe("status unreadable");
    expect(reduce(failed, { kind: "__error_clear", from: "status" }).error).toBe("");
  });

  it("does not clear an error with no source, or one that replaced it", () => {
    const unnamed = run([{ kind: "__error", text: "send refused" }]);
    expect(reduce(unnamed, { kind: "__error_clear", from: "status" }).error).toBe("send refused");
    const replaced = run([
      { kind: "__error", text: "status unreadable", from: "status" },
      { kind: "__error", text: "send refused" },
    ]);
    expect(reduce(replaced, { kind: "__error_clear", from: "status" }).error).toBe("send refused");
  });

  it("is cleared by the person's dismissal whatever its source", () => {
    const failed = run([{ kind: "__error", text: "status unreadable", from: "status" }]);
    expect(reduce(failed, { kind: "__error", text: "" }).error).toBe("");
  });
});

describe("what a turn spent against what the session spent", () => {
  const billed = (amount: number) => ({ kind: "usage", usage: { cacheHitTokens: 1, cacheMissTokens: 1, completionTokens: 1, totalTokens: 3, cost: amount, currency: "CNY", source: "executor" } }) as unknown as SessionEvent;
  const turn = (n: number, amount: number): SessionEvent[] => [{ kind: "turn_started", msgIndex: n } as SessionEvent, billed(amount), { kind: "turn_done" } as SessionEvent];

  it("restarts the turn's amount at each turn while the session total keeps growing", () => {
    const s = run([...turn(1, 1), ...turn(2, 2), ...turn(3, 3)]);
    expect(s.metrics.cost).toEqual([{ currency: "CNY", amount: 6 }]);
    expect(s.metrics.turn).toEqual([{ currency: "CNY", amount: 3 }]);
  });

  it("adds every round of one turn to that turn", () => {
    const s = run([...turn(1, 1), { kind: "turn_started", msgIndex: 2 } as SessionEvent, billed(2), billed(0.5)]);
    expect(s.metrics.turn).toEqual([{ currency: "CNY", amount: 2.5 }]);
    expect(s.metrics.cost).toEqual([{ currency: "CNY", amount: 3.5 }]);
  });

  it("does not restart the turn when the same turn is announced twice", () => {
    const s = run([{ kind: "turn_started", msgIndex: 4 } as SessionEvent, billed(1), { kind: "turn_started", msgIndex: 4 } as SessionEvent, billed(1)]);
    expect(s.metrics.turn).toEqual([{ currency: "CNY", amount: 2 }]);
  });
});
