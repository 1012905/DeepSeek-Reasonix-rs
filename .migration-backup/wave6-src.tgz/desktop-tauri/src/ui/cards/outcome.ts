import type { Tool } from "../../port/wire";
import { t } from "../../i18n";
import { say } from "../../i18n/kernel";
import { workspaceLeaseDetail } from "../../i18n/workspace_lease";

// The host sets err for every failed, timed-out, cancelled or refused call;
// execution.state only describes the run, and a background start is no failure.
export function toolFailed(tool: Tool): boolean {
  return !!tool.err;
}

export function toolChangedFile(tool: Tool): boolean {
  return !!tool.diff || tool.added !== undefined || tool.removed !== undefined;
}

export function toolFailureLabel(tool: Tool): string {
  const execution = tool.execution;
  if ((execution?.exitCode ?? 0) !== 0) return `exit ${execution?.exitCode}`;
  if (execution?.state && execution.state !== "completed") return execution.state;
  // The host names which refusal this was; "失败" is what is left when nobody did.
  if (tool.refusalCode) return tool.refusalCode;
  return t("common.failed");
}

// What the host's refusal code means, in the reader's language; empty when the
// code has no wording here and the kernel's own sentence is all there is.
export function toolRefusalReason(tool: Tool): string {
  const reason = tool.refusalCode ? say({ code: tool.refusalCode }, "") : "";
  return tool.workspaceLease ? [reason, workspaceLeaseDetail(tool.workspaceLease)].filter(Boolean).join(" · ") : reason;
}

// These codes carry a complete user-facing refusal; the raw message is for logs.
export function toolErrorDetail(tool: Tool): string {
  switch (tool.refusalCode) {
    case "workspace.target_access_unconfigured":
    case "workspace.read_forbidden":
    case "workspace.read_outside_scope":
    case "workspace.overwrite_read_forbidden":
    case "workspace.overwrite_read_outside_scope":
    case "video.ffmpeg_missing":
    case "video.unsupported_container":
    case "video.too_large":
    case "shell.mixed_mutation_verification":
    case "shell.inline_interpreter_not_last":
    case "batch.skipped_after_failed_change":
    case "batch.check_after_stopped_call":
      if (toolRefusalReason(tool)) return "";
  }
  return tool.err ?? "";
}

export function toolOutputEchoed(tool: Tool): boolean {
  return !!tool.err && tool.err.trim() === (tool.output ?? "").trim();
}
