import { afterEach, describe, expect, it, vi } from "vitest";
import { DeliveryError, HttpError } from "./port";
import { SseHttp } from "./sse_http";
import { SsePort } from "./sse";

class Probe extends SseHttp {
  call(path: string) {
    return this.post(path, {});
  }
  read<T>(path: string) {
    return this.get<T>(path);
  }
  decide(path: string) {
    return this.postAcked(path, {});
  }
}

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

function deferredFetch() {
  const pending: ((v: unknown) => void)[] = [];
  const fetchMock = vi.fn(
    () =>
      new Promise((resolve) => {
        pending.push((v) => resolve({ ok: true, status: 200, json: async () => v, text: async () => "" }));
      }),
  );
  vi.stubGlobal("fetch", fetchMock);
  return { fetchMock, pending };
}

const tick = () => new Promise((r) => setTimeout(r, 0));

it("typed surface answers retain JSON values on the wire", async () => {
  const fetchMock = vi.fn(async (_url: string, _init: RequestInit) => ({ ok:true, status:204, text:async () => "" }));
  vi.stubGlobal("fetch", fetchMock);
  await new SsePort("", "r1").answer("ask-1", [{ questionId:"surface", selected:[], value:{ count:2, enabled:false, tags:["fast"] } }]);
  const init = fetchMock.mock.calls[0][1] as RequestInit;
  expect(JSON.parse(String(init.body))).toEqual({ id:"ask-1", answers:[{ QuestionID:"surface", Selected:[], Value:{ count:2, enabled:false, tags:["fast"] } }] });
});

describe("idempotent reads", () => {
  it("share one request while it is in flight, with one trailing re-read for the rest", async () => {
    const { fetchMock, pending } = deferredFetch();
    const probe = new Probe();
    const first = probe.read("/status");
    const second = probe.read("/status");
    const third = probe.read("/status");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    pending[0]({ n: 1 });
    expect(await first).toEqual({ n: 1 });
    await tick();
    expect(fetchMock).toHaveBeenCalledTimes(2);
    pending[1]({ n: 2 });
    expect(await second).toEqual({ n: 2 });
    expect(await third).toEqual({ n: 2 });
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("never hands a trigger an answer that began before it", async () => {
    const { pending } = deferredFetch();
    const probe = new Probe();
    const early = probe.read<{ n: number }>("/status");
    const late = probe.read<{ n: number }>("/status");
    pending[0]({ n: 1 });
    await early;
    await tick();
    pending[1]({ n: 2 });
    expect((await late).n).toBe(2);
  });

  it("keeps different paths apart", async () => {
    const { fetchMock } = deferredFetch();
    const probe = new Probe();
    void probe.read("/status");
    void probe.read("/context");
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("does not let a failed read poison the next one", async () => {
    let n = 0;
    const fetchMock = vi.fn(async () => {
      n++;
      if (n === 1) throw new TypeError("Failed to fetch");
      return { ok: true, status: 200, json: async () => ({ n }), text: async () => "" };
    });
    vi.stubGlobal("fetch", fetchMock);
    const probe = new Probe();
    await expect(probe.read("/status")).rejects.toBeInstanceOf(DeliveryError);
    expect(await probe.read("/status")).toEqual({ n: 2 });
  });

  it("names an unreachable kernel and the read, not the browser's bare fetch failure", async () => {
    vi.stubGlobal("fetch", async () => {
      throw new TypeError("Failed to fetch");
    });
    const err = (await new Probe().read("/status").catch((e) => e)) as DeliveryError;
    expect(err).toBeInstanceOf(DeliveryError);
    expect(err.fault).toBe("unreachable");
    expect(err.path).toBe("/status");
  });
});

describe("a decision submit", () => {
  it("fails with a typed error instead of waiting forever", async () => {
    vi.useFakeTimers();
    vi.stubGlobal("fetch", (_: string, init: RequestInit) =>
      new Promise((_resolve, reject) => {
        init.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")));
      }),
    );
    const settled = new Probe().decide("/approve").catch((e) => e);
    await vi.advanceTimersByTimeAsync(60_000);
    const err = (await settled) as DeliveryError;
    expect(err).toBeInstanceOf(DeliveryError);
    expect(err.fault).toBe("kernel_busy");
  });

  it("keeps a refusal it already received when the wait runs out mid-body", async () => {
    vi.useFakeTimers();
    vi.stubGlobal("fetch", async (_: string, init: RequestInit) => ({
      ok: false,
      status: 409,
      text: () =>
        new Promise<string>((_resolve, reject) => {
          init.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")));
        }),
    }));
    const settled = new Probe().decide("/plan-decision").catch((e) => e);
    await vi.advanceTimersByTimeAsync(60_000);
    const err = await settled;
    expect(err).not.toBeInstanceOf(DeliveryError);
    expect((err as HttpError).status).toBe(409);
  });

  it("goes through untouched when the kernel answers", async () => {
    vi.stubGlobal("fetch", async () => ({ ok: true, status: 204, text: async () => "" }));
    await expect(new Probe().decide("/approve")).resolves.toBeUndefined();
  });

  it("still carries a refusal's code", async () => {
    answer(409, JSON.stringify({ code: "gate.stale", error: "stale" }), "application/json");
    const err = (await new Probe().decide("/approve").catch((e) => e)) as HttpError;
    expect(err.reason?.code).toBe("gate.stale");
  });
});

function answer(status: number, body: string, contentType: string) {
  vi.stubGlobal("fetch", async () => ({
    ok: false,
    status,
    text: async () => body,
    json: async () => JSON.parse(body),
    headers: new Map([["content-type", contentType]]),
  }));
}

const silentKernel = () =>
  vi.stubGlobal("fetch", (_: string, init: RequestInit) =>
    new Promise((_resolve, reject) => {
      init.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")));
    }),
  );

describe("an unconfirmed call is told apart by who held it up", () => {
  it("a stop the kernel never acknowledged ends as a typed error, not a wait with no end", async () => {
    vi.useFakeTimers();
    silentKernel();
    const settled = new SsePort("", "r1").cancel().then(() => "acked", (e) => e);
    await vi.advanceTimersByTimeAsync(60_000);
    const err = await settled;
    expect(err).toBeInstanceOf(DeliveryError);
    expect((err as DeliveryError).fault).toBe("kernel_busy");
  });

  it("a stop the kernel acknowledged settles", async () => {
    const calls: string[] = [];
    vi.stubGlobal("fetch", async (url: string) => {
      calls.push(url);
      return { ok: true, status: 204, text: async () => "" };
    });
    await expect(new SsePort("", "r1").cancel()).resolves.toBeUndefined();
    expect(calls).toEqual(["/cancel"]);
  });

  it("blames this window, not the kernel, when the deadline fires far past its time", async () => {
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
    let now = 1_000;
    vi.spyOn(performance, "now").mockImplementation(() => now);
    silentKernel();
    const settled = new Probe().decide("/approve").catch((e) => e);
    now += 90_000;
    await vi.advanceTimersByTimeAsync(20_000);
    expect(((await settled) as DeliveryError).fault).toBe("ui_stalled");
    vi.restoreAllMocks();
  });

  it("blames the kernel when the deadline fires on time", async () => {
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
    let now = 1_000;
    vi.spyOn(performance, "now").mockImplementation(() => now);
    silentKernel();
    const settled = new Probe().decide("/approve").catch((e) => e);
    now += 20_050;
    await vi.advanceTimersByTimeAsync(20_000);
    expect(((await settled) as DeliveryError).fault).toBe("kernel_busy");
    vi.restoreAllMocks();
  });

  it("reports a refused connection as unreachable", async () => {
    vi.stubGlobal("fetch", async () => {
      throw new TypeError("Failed to fetch");
    });
    const err = (await new Probe().decide("/approve").catch((e) => e)) as DeliveryError;
    expect(err).toBeInstanceOf(DeliveryError);
    expect(err.fault).toBe("unreachable");
  });

  it("keeps a refusal the kernel spelled out for a stop", async () => {
    vi.stubGlobal("fetch", async () => ({ ok: false, status: 403, text: async () => '{"code":"x.y","error":"no"}' }));
    const err = (await new SsePort("", "r1").cancel().catch((e) => e)) as HttpError;
    expect(err).toBeInstanceOf(HttpError);
    expect(err.reason?.code).toBe("x.y");
  });
});

describe("a failed call", () => {
  // http.Error writes plain text, and parsing the body as JSON first threw the
  // only account of the failure away: users reported "/providers/edit: 500".
  it("carries a plain-text reason through", async () => {
    answer(500, "save user config: config is locked by another Reasonix process", "text/plain");
    const err = (await new Probe().call("/providers/edit").catch((e) => e)) as HttpError;
    expect(err).toBeInstanceOf(HttpError);
    expect(err.status).toBe(500);
    expect(err.message).toContain("locked by another Reasonix process");
  });

  it("still prefers the refusal envelope when there is one", async () => {
    answer(400, JSON.stringify({ code: "provider.no_models_picked", error: "pick at least one model" }), "application/json");
    const err = (await new Probe().call("/providers/edit").catch((e) => e)) as HttpError;
    expect(err.message).toBe("pick at least one model");
    expect(err.reason?.code).toBe("provider.no_models_picked");
  });

  // With nothing to report, the path and status are all a reader can be given.
  it("falls back to the path and status on an empty body", async () => {
    answer(502, "", "text/plain");
    const err = (await new Probe().call("/providers/edit").catch((e) => e)) as HttpError;
    expect(err.message).toBe("/providers/edit: 502");
  });
});

// The kernel answers a closed browser tab with 204 and no body, so closing is
// settled by the status alone.
describe("closing a browser tab", () => {
  it("succeeds on an empty 204 answer", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(null, { status: 204 })));
    await expect(new SsePort("").browserClose("tab-1")).resolves.toBeUndefined();
  });
});
