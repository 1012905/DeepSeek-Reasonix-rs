import { watchTree } from "./tree_events";
import { HttpError, type AgentPort } from "./port";
import type { RemoteAsk, RemoteHost, RemoteHostEdit, RemoteListing, RemoteProbe, WSLDistros } from "./remote";
import type { CloudShareOffer, DeviceSelf, PhoneAction, PhoneList, ShareOffer, SharePort, ShareStatus } from "./share";
import { SsePort } from "./sse";
import { host } from "./host";

// How often a client waiting on a dial looks for the question it might be
// stopped by. A person answers this one, so half a second is not the cost —
// and a missed round loses nothing, because the snapshot is the record.
const ASK_POLL_MS = 500;

// Must match operationHeader in internal/frontend/serve. The caller names the operation
// because the question can arrive before the response does.
function operationHeaders(operationId?: string): Record<string, string> {
  return operationId ? { "x-reasonix-operation-id": operationId } : {};
}

// RuntimeView is one open pane. Base is the prefix every request of that pane
// carries, which is also what tells the shell's bus which channel to listen on.
export interface RuntimeView {
  agentComposition?: import("./composition").CompositionSummary;
  id: string;
  base: string;
  root: string;
  name: string;
  sessionPath?: string;
  // Set only on a pane whose kernel runs on another machine, naming it. Absence
  // is what marks a pane as this machine's own, so the common case stays plain.
  host?: string;
  // Set on a pane showing a conversation another window or process holds the
  // write lease for. It reads and scrolls like any other; what it cannot do is
  // add to it.
  readOnly?: boolean;
}

export interface TreeSession {
	metadataState?: "pending" | "ready" | "error";
	countsKnown?: boolean;
  path: string;
  workspaceRoot?: string;
  isolated?: boolean;
  name: string;
  title?: string;
  turns?: number;
  // Unix ms of the last write to this conversation; absent when unknown.
  lastActiveAt?: number;
  // Set when a pane already drives this transcript: the sidebar focuses that
  // pane rather than opening a second writer for one file.
  runtimeId?: string;
  archived?: boolean;
  // Set when Reasonix 1.x kept this transcript: it is read here and never
  // written, so the row says which store it came from.
  legacy?: boolean;
  // The kernel is the authority for pins.
  pinned?: boolean;
  // Unix ms of an automatic archive, absent for a manual one.
  autoArchivedAt?: number;
  // A turn finished since the person last looked. Absent means seen.
  unread?: boolean;
  // Unix ms of the last time the person looked, sent only while the row is
  // unread; absent from a kernel that predates it.
  viewedAt?: number;
  // Conflict-recovery copies of this same conversation. A save that keeps
  // conflicting writes one per turn, all under one title.
  copies?: TreeSession[];
  // This conversation as it stood before each edit, regenerate or rewind cut
  // it, newest first. Each opens as a whole conversation.
  versions?: TreeSession[];
}

export type LegacySkipReason = "too_large" | "unreadable_format" | "schema_unsupported" | "permission" | "corrupt" | "copy_failed" | "no_project";

// A 1.x session the import could not read. The entry at `path` was neither
// moved nor deleted.
export interface LegacySkip {
  source: string;
  name: string;
  path: string;
  reason: LegacySkipReason;
}

export interface LegacyImport {
  summary: string;
  imported: number;
  warnings: number;
  recognised: boolean;
  skipped: LegacySkip[];
}

export interface HostCapabilities {
  // The kernel can open a picker on its own machine. A browser on a headless
  // server gets false and must offer the path API instead.
  pickFolder: boolean;
  // The kernel exposes POST /tree/workspaces. This is what makes the fallback
  // meaningful rather than sending the reader back to the desktop shell.
  addWorkspace: boolean;
}

export interface OpenWithTarget {
  id: string;
  name: string;
  available: boolean;
  why?: string;
  within?: string;
}

export interface TreeWorkspace {
	listingState?: "discovering" | "indexing" | "ready" | "degraded";
	listingRevision?: number;
	countsComplete?: boolean;
	pendingMetadata?: number;
	failedMetadata?: number;
  // Echoed only by kernels that serve globally ordered recent pages.
  recentOffset?: number;
  root: string;
  name: string;
  workspaceRoots?: string[];
  isolated?: boolean;
  missing?: boolean;
  open?: boolean;
  // True when the user chose this folder. A window always has a root — the one
  // it happened to launch in — and only this tells that apart from a project.
  remembered?: boolean;
  // Every conversation the folder lists, loaded or not, and how many of those
  // are archived. `sessions` is only the newest of them; a kernel that predates
  // paging sends neither, and then `sessions` is all there is.
  total?: number;
  archived?: number;
  // Matching rows after this page/window. Absent on kernels predating paging.
  remaining?: number;
  sessions: TreeSession[];
}

export function workspaceContains(workspace: TreeWorkspace, root: string | undefined): boolean {
  return root !== undefined && (workspace.root === root || !!workspace.workspaceRoots?.includes(root));
}

// The sessions a tree request counts, independently of its ordering.
export type TreeScope = "" | "active" | "archived";

// Ordinary windows bound each project; recent windows page across all projects.
// `q` filters titles/names and project names before either window is selected.
export interface TreeWindow {
	retryMetadata?: boolean;
  order?: "recent";
  // Recent pages are global across projects, unlike each project's tree window.
  offset?: number;
  hideLegacy?: boolean;
  // 0 means all rows; `limits` overrides this per project in ordinary windows.
  limit?: number;
  limits?: Record<string, number>;
  scope?: TreeScope;
  q?: string;
}

export function treeQuery(window: TreeWindow | undefined): string {
  const q = new URLSearchParams();
  if (window?.retryMetadata) q.set("retryMetadata", "1");
  if (window?.order) q.set("order", window.order);
  if (window?.offset !== undefined) q.set("offset", String(window.offset));
  if (window?.hideLegacy) q.set("hideLegacy", "1");
  if (window?.limit !== undefined) q.set("limit", String(window.limit));
  if (window?.limits && Object.keys(window.limits).length > 0) q.set("limits", JSON.stringify(window.limits));
  if (window?.scope) q.set("scope", window.scope);
  if (window?.q?.trim()) q.set("q", window.q.trim());
  const s = q.toString();
  return s ? `?${s}` : "";
}

// HubPort is the window's view of the kernel: which panes it drives and which
// folders it can open. One AgentPort hangs off each pane.
/** One conversation whose words matched, with the passage that matched. */
export interface HistoryHit {
  path: string;
  id: string;
  title?: string;
  workspace?: string;
  snippet: string;
  role: string;
  messageIndex: number;
  score: number;
}

/** What the projection could answer for, in the counters the kernel already
 *  keeps. A source it could not read is left out of the hits, so this is the
 *  only thing that tells that answer apart from a genuinely empty one. */
export interface HistoryIndex {
  state: string;
  indexed: number;
  total: number;
  failed: number;
  partial: boolean;
  reason?: "failed" | "building";
}

export interface HistorySearch {
  hits: HistoryHit[];
  index: HistoryIndex;
}

export interface HubPort extends SharePort {
  runtimes(): Promise<RuntimeView[]>;
  open(req: { root?: string; sessionPath?: string; agentComposition?: string }): Promise<RuntimeView>;
  close(id: string): Promise<void>;
  tree(window?: TreeWindow): Promise<TreeWorkspace[]>;
  /** Conversations, in every workspace, that say these words. */
  searchHistory(query: string): Promise<HistorySearch>;
  onTreeChanged(listener: () => void): () => void;
  addWorkspace(path: string): Promise<TreeWorkspace>;
  removeWorkspace(path: string): Promise<void>;
  /** Show a listed project's folder in the system file manager. */
  revealWorkspace(path: string): Promise<void>;
  openWorkspace(path: string): Promise<void>;
  /** The programs a project can be opened in, as this machine has them. */
  openWithTargets(): Promise<OpenWithTarget[]>;
  /** Open a listed project in one of those programs. */
  openWith(path: string, target: string): Promise<void>;
  moveWorkspace(path: string, direction: -1 | 1): Promise<void>;
  moveSession(path: string, direction: -1 | 1): Promise<void>;
  /** Drop a project before another remembered one, or at the end when `before` is empty. */
  placeWorkspace(path: string, before: string): Promise<void>;
  removeSession(path: string): Promise<void>;
  /** The conversation moves into the named project; originalRemoved is false when the copy arrived but the original could not be taken away. */
  moveSessionTo(path: string, target: string): Promise<{ path: string; originalRemoved: boolean }>;
  archiveSession(path: string, archived: boolean, host?: string): Promise<void>;
  // Tells the kernel which conversations automatic archiving must leave alone.
  pinSession(path: string, pinned: boolean, host?: string): Promise<void>;
  // Clears one saved conversation's unread mark without opening it; a remote host
  // that predates the route refuses and the caller reports it.
  markSessionRead(path: string, host?: string): Promise<void>;
  // Adds pins made before the kernel kept them. The first call also opens the
  // gate: until then the kernel archives nothing on its own.
  syncPins(paths: string[]): Promise<void>;
  renameSession(path: string, title: string): Promise<void>;
  autoNameSession(path: string): Promise<{ title: string }>;
  exportSession(path: string): Promise<{ name: string; content: string }>;
  importLegacySessions(path: string, workspace: string): Promise<LegacyImport>;
  importNativeSession(file: Blob, workspace: string): Promise<{ path: string }>;
  // The host book with each link's state, or null where this kernel refuses
  // remote panes outright — a page served to a browser, rather than the window.
  // Null is what lets the sidebar leave the whole section out instead of
  // drawing a header over a feature that cannot work here.
  remoteHosts(): Promise<RemoteHost[] | null>;
  // Opens a pane on another machine. Slow the first time — the kernel may be
  // installing itself over there — so the caller polls remoteHosts for the step.
  openRemote(req: { host: string; workspace?: string; sessionPath?: string; agentComposition?:string }): Promise<RuntimeView>;
  // The far machine's own workspaces, or null while nothing is open on it:
  // there is no kernel over there to ask until a pane puts one there.
  remoteTree(host: string, window?: TreeWindow): Promise<TreeWorkspace[] | null>;
  // Erases a conversation on that machine; its kernel decides whether it may.
  removeRemoteSession(host: string, path: string): Promise<void>;
  // Folders on the far machine, read over the link alone — no kernel has to be
  // installed over there to answer it, which is why picking one works on a
  // machine nothing is open on. An empty path is that machine's login home.
  remoteDirs(host: string, path?: string): Promise<RemoteListing>;
  /** What that machine can do, without changing anything on it. A cold connect
   *  stops at the first missing piece; this asks for all of them at once. */
  probeRemote(host: string): Promise<RemoteProbe>;
  // The host book's folder list, written one entry at a time. The settings page
  // replaces a whole row; a control that knows one folder must not, or it sends
  // back blanks for every field it never displayed.
  addRemoteWorkspace(host: string, path: string): Promise<void>;
  removeRemoteWorkspace(host: string, path: string): Promise<void>;
  saveRemoteHost(entry: RemoteHostEdit): Promise<void>;
  removeRemoteHost(name: string): Promise<void>;
  // Puts a machine before another in the book, or last when before is empty.
  placeRemoteHost(name: string, before: string): Promise<void>;
  // ssh_config aliases this machine can already reach and the book has not
  // taken yet. Filling it by hand when the addresses are written down next
  // door is the step people skip.
  remoteCandidates(): Promise<string[]>;
  // The WSL distributions on this machine, for the choice of one as a host.
  wslDistros(): Promise<WSLDistros>;
  // Questions a connect stopped for. Nothing arrives here in a browser: the
  // kernel that would ask is the one this build cannot reach.
  onRemoteAsk(cb: (ask: RemoteAsk) => void): () => void;
  answerRemote(id: string, ok: boolean, text: string): void;
  // What the kernel can do independently of the desktop window. It is a
  // separate read so the page can choose a usable fallback before invoking a
  // host-only action.
  hostCapabilities(): Promise<HostCapabilities>;
  pickFolder(): Promise<string | null>;
  // Machine settings resolve a local owner; workspace reads can pin a runtime.
  machinePort(runtimeId?: string): AgentPort;
  // Absolute paths of every file dropped anywhere on the window. It belongs
  // here rather than on a pane because the window has one of it: the shell
  // registers its drop listener once and ignores a second call, so a per-pane
  portFor(rt: RuntimeView): AgentPort;
}

type HubRefusal = { code?: string; error?: string; params?: Record<string, string | number> };

export class SseHub implements HubPort {
  // One port per pane, kept across renders: a fresh instance would resubscribe
  // the event stream on every parent render and drop frames in between.
  private readonly ports = new Map<string, AgentPort>();
  // What this machine's kernel says it can drive at once, learned from the
  // last list. The default matches the kernel's own until one arrives.
  // Bindings the shell exposes are pane-independent; this reaches them without
  // pretending to belong to a runtime.
  private readonly shell: SsePort;
  private readonly mux: boolean;
  private readonly settings = new Map<string, AgentPort>();
  // Questions seen this session, kept so an answer can carry the identities the
  // kernel will check it against.
  private readonly asked = new Map<string, RemoteAsk>();
  private readonly askSubs = new Set<(ask: RemoteAsk) => void>();
  private dialing = 0;
  private askTimer: ReturnType<typeof setInterval> | null = null;

  constructor(options: { mux?: boolean } = {}) {
    this.mux = options.mux !== false;
    this.shell = new SsePort("", "", this.mux);
  }

  // A refusal carries a code, and it is the code that has words in the reader's
  // language. Flattening the body into the message threw that away: what
  // reached the screen was the raw JSON, or a filesystem error naming a path.
  //
  // Read once as text, the way SseHttp does: not every answer is an envelope —
  // http.Error writes its reason as plain text, and asking for JSON first threw
  // that account away and left "the request never reached the kernel" in front
  // of a user whose kernel had just explained itself at length.
  private static async fail(path: string, res: Response): Promise<never> {
    const raw = (await res.text().catch(() => "")).trim();
    let body: HubRefusal | null = null;
    try {
      const parsed: unknown = raw === "" ? null : JSON.parse(raw);
      if (parsed && typeof parsed === "object") body = parsed as HubRefusal;
    } catch {
      // Plain text, which is the whole message.
    }
    const detail = body?.error || raw.slice(0, 400);
    throw new HttpError(res.status, detail || `${path}: ${res.status}`, body ?? undefined, detail !== "");
  }

  private async get<T>(path: string, operationId?: string): Promise<T> {
    const res = await fetch(path, { credentials: "same-origin", headers: operationHeaders(operationId) });
    if (!res.ok) await SseHub.fail(path, res);
    return (await res.json()) as T;
  }

  private async post<T>(path: string, body?: unknown, operationId?: string): Promise<T> {
    const res = await fetch(path, {
      method: "POST",
      headers: { "content-type": "application/json", ...operationHeaders(operationId) },
      credentials: "same-origin",
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (!res.ok) await SseHub.fail(path, res);
    return res.status === 204 ? (undefined as T) : ((await res.json()) as T);
  }

  // The ceiling comes back on the response rather than being hardcoded here:
  // the machine's own [desktop] max_panes decides it, and a client guessing 8
  // greys out the button at the wrong count.
  async runtimes() {
    const res = await fetch("/runtimes", { credentials: "same-origin" });
    if (!res.ok) throw new Error(`/runtimes: ${res.status}`);
    return (await res.json()) as RuntimeView[];
  }

  open(req: { root?: string; sessionPath?: string; agentComposition?: string }) {
    return this.post<RuntimeView>("/runtimes", { root: req.root ?? "", sessionPath: req.sessionPath ?? "", agentComposition: req.agentComposition });
  }

  async close(id: string) {
    try {
      await this.post<void>(`/runtimes/${encodeURIComponent(id)}/close`);
    } catch (e) {
      // A pane the kernel no longer holds is already closed.
      if (!(e instanceof HttpError && e.reason?.code === "request.not_found")) throw e;
    }
    this.ports.delete(id);
    this.settings.delete(id);
  }

  onTreeChanged(listener: () => void) {
    return watchTree(listener);
  }

  tree(window?: TreeWindow) {
    const query = treeQuery(window);
    return this.get<TreeWorkspace[]>("/tree" + query + (query ? "&" : "?") + "progressive=1");
  }

  searchHistory(query: string) {
    return this.get<HistorySearch>("/history/search?q=" + encodeURIComponent(query));
  }

  addWorkspace(path: string) {
    return this.post<TreeWorkspace>("/tree/workspaces", { path });
  }

  async revealWorkspace(path: string) {
    const why = await host().revealWorkspace(path);
    if (why) throw new HttpError(0, why.error || "not shown", why, !!(why.code || why.error));
  }

  async openWorkspace(path: string) {
    const why = await host().openWorkspace(path);
    if (why) throw new HttpError(0, why.error || "not opened", why, !!(why.code || why.error));
  }

  async openWithTargets() {
    return (await this.get<{ targets: OpenWithTarget[] | null }>("/host/open-with")).targets ?? [];
  }

  async openWith(path: string, target: string) {
    await this.post<void>("/host/open-with", { id: target, root: path });
  }

  async removeWorkspace(path: string) {
    await this.post<void>("/tree/workspaces/remove", { path });
  }

  async moveWorkspace(path: string, direction: -1 | 1) {
    await this.post<void>("/tree/workspaces/move", { path, direction });
  }

  async moveSession(path: string, direction: -1 | 1) {
    await this.post<void>("/tree/sessions/move", { path, direction });
  }

  async placeWorkspace(path: string, before: string) {
    await this.post<void>("/tree/workspaces/move", { path, before });
  }

  async moveSessionTo(path: string, target: string) {
    return this.post<{ path: string; originalRemoved: boolean }>("/tree/sessions/move-to", { path, target });
  }

  async removeSession(path: string) {
    await this.post<void>("/tree/sessions/remove", { path });
  }

  async archiveSession(path: string, archived: boolean, host?: string) {
    await this.post<void>(host ? `/remotes/${encodeURIComponent(host)}/sessions/archive` : "/tree/sessions/archive", { path, archived });
  }

  async pinSession(path: string, pinned: boolean, host?: string) {
    await this.post<void>(host ? `/remotes/${encodeURIComponent(host)}/sessions/pin` : "/tree/sessions/pin", { path, pinned });
  }

  async markSessionRead(path: string, host?: string) {
    await this.post<void>(host ? `/remotes/${encodeURIComponent(host)}/sessions/viewed` : "/tree/sessions/viewed", { path });
  }

  async syncPins(paths: string[]) {
    await this.post<void>("/tree/sessions/pins", { paths });
  }

  async renameSession(path: string, title: string) {
    await this.post<void>("/tree/sessions/rename", { path, title });
  }

  autoNameSession(path: string) {
    return this.post<{ title: string }>("/tree/sessions/auto-name", { path });
  }

  exportSession(path: string) {
    return this.post<{ name: string; content: string }>("/tree/sessions/export", { path });
  }

  importLegacySessions(path: string, workspace: string) {
    return this.post<LegacyImport>("/tree/sessions/import-legacy", { path, workspace });
  }

  async importNativeSession(file: Blob, workspace: string): Promise<{ path: string }> {
    const path = `/tree/sessions/import-native?${new URLSearchParams({ workspace })}`;
    const response = await fetch(path, {
      method: "POST", credentials: "same-origin",
      headers: { "content-type": "application/json" }, body: file,
    });
    if (!response.ok) await SseHub.fail(path, response);
    return await response.json() as { path: string };
  }

  async remoteHosts() {
    const res = await fetch("/remotes", { credentials: "same-origin" });
    // Not an error to report: this kernel does not do remote panes, or answers
    // a paired device, which the window's own routes are not found for.
    if (res.status === 501 || res.status === 404) return null;
    if (!res.ok) await SseHub.fail("/remotes", res);
    return (await res.json()) as RemoteHost[];
  }

  openRemote(req: { host: string; workspace?: string; sessionPath?: string; agentComposition?:string }) {
    return this.dial((operationId) =>
      this.post<RuntimeView>(
        "/remotes/open",
        { host: req.host, workspace: req.workspace ?? "", sessionPath: req.sessionPath ?? "", agentComposition: req.agentComposition },
        operationId,
      ),
    );
  }

  async removeRemoteSession(host: string, path: string) {
    await this.post<void>(`/remotes/${encodeURIComponent(host)}/sessions/remove`, { path });
  }

  async remoteTree(host: string, window?: TreeWindow) {
    const path = `/remotes/${encodeURIComponent(host)}/tree` + treeQuery(window);
    const res = await fetch(path, { credentials: "same-origin" });
    if (!res.ok) await SseHub.fail(path, res);
    return (await res.json()) as TreeWorkspace[];
  }

  probeRemote(host: string) {
    return this.dial((operationId) =>
      this.get<RemoteProbe>(`/remotes/${encodeURIComponent(host)}/probe`, operationId),
    );
  }

  remoteDirs(host: string, path?: string) {
    const at = path ? `?path=${encodeURIComponent(path)}` : "";
    return this.dial((operationId) =>
      this.get<RemoteListing>(`/remotes/${encodeURIComponent(host)}/dirs${at}`, operationId),
    );
  }

  async addRemoteWorkspace(host: string, path: string) {
    await this.post<void>(`/remotes/${encodeURIComponent(host)}/workspaces`, { path });
  }

  async removeRemoteWorkspace(host: string, path: string) {
    await this.post<void>(`/remotes/${encodeURIComponent(host)}/workspaces/remove`, { path });
  }

  async saveRemoteHost(entry: RemoteHostEdit) {
    await this.post<void>("/remotes", entry);
  }

  async removeRemoteHost(name: string) {
    await this.post<void>("/remotes/remove", { name });
  }

  async placeRemoteHost(name: string, before: string) {
    await this.post<void>(`/remotes/${encodeURIComponent(name)}/place`, { before });
  }

  remoteCandidates() {
    return this.get<string[]>("/remotes/candidates");
  }

  wslDistros() {
    return this.get<WSLDistros>("/remotes/wsl");
  }

  // The question is state the kernel holds, and this is how it is found. No
  // stream carries it: it exists only while a dial this client started is still
  // waiting, and that is a thing the client already knows.
  onRemoteAsk(cb: (ask: RemoteAsk) => void) {
    this.askSubs.add(cb);
    return () => {
      this.askSubs.delete(cb);
    };
  }

  answerRemote(id: string, ok: boolean, text: string) {
    const ask = this.asked.get(id);
    if (!ask) return;
    this.asked.delete(id);
    // Sending the same answer twice is safe by design, which is what lets this
    // be fired and forgotten: a lost response must not strand the dial.
    void fetch(`/asks/${encodeURIComponent(id)}/answer`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ epoch: ask.epoch, operationId: ask.operationId, answer: { ok, text } }),
    }).catch(() => {});
  }

  // dial runs a request that may stop to ask something. The question arrives
  // before this response does, so the operation names itself up front and the
  // client looks for questions under that name while it waits.
  private async dial<T>(run: (operationId: string) => Promise<T>): Promise<T> {
    const operationId = crypto.randomUUID();
    this.dialing++;
    void this.sweepAsks();
    this.askTimer ??= setInterval(() => void this.sweepAsks(), ASK_POLL_MS);
    try {
      return await run(operationId);
    } finally {
      this.dialing--;
      if (this.dialing === 0 && this.askTimer !== null) {
        clearInterval(this.askTimer);
        this.askTimer = null;
      }
    }
  }

  // A missed round costs nothing: the snapshot is the record, so the next one
  // still holds whatever is open.
  private async sweepAsks() {
    const res = await fetch("/asks", { credentials: "same-origin" }).catch(() => null);
    if (!res?.ok) return;
    const body = (await res.json().catch(() => null)) as { asks?: RemoteAsk[] } | null;
    for (const ask of body?.asks ?? []) {
      if (this.asked.has(ask.askId)) continue;
      this.asked.set(ask.askId, ask);
      this.askSubs.forEach((cb) => cb(ask));
    }
  }

  async hostCapabilities() {
    const shellCanPick = await host()
      .describe()
      .then((info) => info.shell !== "browser")
      .catch(() => false);

    const res = await fetch("/host/capabilities", { credentials: "same-origin" });
    // A kernel predating this probe has no route and keeps the old picker
    // attempt; the caller already treats null as "no picker" safely.
    if (res.status === 404 || res.status === 501 || res.status === 503) {
      return { pickFolder: true, addWorkspace: true };
    }
    if (!res.ok) await SseHub.fail("/host/capabilities", res);

    const body = (await res.json().catch(() => null)) as Partial<HostCapabilities> | null;
    if (typeof body?.pickFolder !== "boolean" || typeof body.addWorkspace !== "boolean") {
      return { pickFolder: true, addWorkspace: true };
    }
    return {
      pickFolder: shellCanPick || body.pickFolder,
      addWorkspace: body.addWorkspace,
    };
  }

  async pickFolder() {
    const shellPath = await this.shell.pickFolder();
    if (shellPath !== null) return shellPath;

    // A browser cannot reveal an absolute local path, but this UI is served by
    // the loopback kernel on the same machine. Let that trusted local process
    // open the platform picker; the page receives only the selected path.
    const res = await fetch("/host/pick-folder", {
      method: "POST",
      headers: { "content-type": "application/json" },
      credentials: "same-origin",
      body: "{}",
    });
    if (res.status === 501 || res.status === 404) return null;
    if (!res.ok) await SseHub.fail("/host/pick-folder", res);
    const body = (await res.json()) as { path?: string };
    return body.path ?? "";
  }

  async shareStatus() {
    const res = await fetch("/share", { credentials: "same-origin" });
    if (res.status === 404) return null;
    if (!res.ok) await SseHub.fail("/share", res);
    return (await res.json()) as ShareStatus;
  }

  openShare(ip: string) {
    return this.post<ShareStatus>("/share/open", { ip });
  }

  closeShare() {
    return this.post<ShareStatus>("/share/close", {});
  }

  async shareRemember() {
    const res = await fetch("/share/remember", { credentials: "same-origin" });
    if (!res.ok) await SseHub.fail("/share/remember", res);
    return (await res.json()) as { remember: boolean };
  }

  setShareRemember(remember: boolean) {
    return this.post<{ remember: boolean }>("/share/remember", { remember });
  }

  setSharePort(port: number) {
    return this.post<ShareStatus>("/share/port", { port });
  }

  offerShare() {
    return this.post<ShareOffer>("/share/offer", {});
  }

  offerCloudShare() {
    return this.post<CloudShareOffer>("/share/cloud-offer", {});
  }

  revokeDevice(id: string) {
    return this.post<ShareStatus>("/share/revoke", { id });
  }

  async sharePhones() {
    const res = await fetch("/share/phones", { credentials: "same-origin" });
    if (res.status === 404) return null;
    if (!res.ok) await SseHub.fail("/share/phones", res);
    return (await res.json()) as PhoneList;
  }

  resolvePhone(id: string, action: PhoneAction, replaceId?: string) {
    return this.post<PhoneList>("/share/phones/resolve", { id, action, ...(replaceId ? { replaceId } : {}) });
  }

  revokePhone(id: string) {
    return this.post<PhoneList>("/share/phones/revoke", { id });
  }

  async device() {
    const res = await fetch("/device", { credentials: "same-origin" });
    if (res.status === 404) return null;
    if (!res.ok) await SseHub.fail("/device", res);
    return (await res.json()) as DeviceSelf;
  }

  async leaveDevice() {
    await this.post<void>("/device/leave", {});
  }

  machinePort(runtimeId = ""): AgentPort {
    const held = this.settings.get(runtimeId);
    if (held) return held;
    const base = runtimeId ? `/host/settings/runtime/${encodeURIComponent(runtimeId)}` : "/host/settings";
    const port = new SsePort(base, "", this.mux);
    this.settings.set(runtimeId, port);
    return port;
  }

  portFor(rt: RuntimeView): AgentPort {
    const held = this.ports.get(rt.id);
    if (held) return held;
    const port = new SsePort(rt.base, rt.id, this.mux);
    this.ports.set(rt.id, port);
    return port;
  }
}
