// provider.ts — a model source as the connection panel edits it: what was
// probed, what was confirmed, and the few fields no probe can answer.

export interface ProviderHealthSettings {
  enabled: boolean;
}

export interface ProviderHealth {
  connection: string;
  wallet: string;
  checkedAt: number;
}

export interface ProviderEntry {
  name: string;
  // The label a person gave this source. Only ever shown: every ref, the
  // default model and saved sessions keep pointing at name.
  displayName?: string;
  // The vendor slug the source's preset declares; absent for a hand-written source.
  mark?: string;
  kind: string;
  baseUrl: string;
  models: string[];
  modelAliases?: Record<string, string>;
  // Whether the prefix every model shares is left out of how they are drawn, and each
  // model as it then reads; a model drawn as it is has no entry.
  hideModelPrefix?: boolean;
  modelShorts?: Record<string, string>;
  default: string;
  hasKey: boolean;
  keyEnv?: string;
  // Which of them read images, so an editor shows the current answer rather
  // than asking the user to remember it.
  visionModels?: string[];
  // False where the kernel refuses image input for every model on this endpoint
  // regardless of config, so an editor can say so instead of offering a dead
  // switch. visionSettable narrows it to the models the refusal spares — one
  // endpoint serves text-only and image-taking models side by side.
  canSetVision?: boolean;
  visionSettable?: string[];
  // The endpoint-executed search tool. canWebSearch says this door offers one
  // at all; webSearch whether it is on. They differ between an account's doors.
  canWebSearch?: boolean;
  webSearch?: boolean;
  // False where the entry's protocol declares no model listing, so the editor
  // offers no control to read one. Absent is a kernel that predates the field.
  canListModels?: boolean;
  // Whether thinking/reasoning_effort may go on the wire. canSetThinking is
  // false where the protocol never carries them, so the switch appears only
  // where a relay can actually reject the request over it.
  canSetThinking?: boolean;
  sendsThinking?: boolean;
  // Where a chosen effort level lands in this entry's request body, as a dotted
  // path; absent when its resolved reasoning protocol reshapes the request.
  effortField?: string;
  // How this endpoint carries context between turns, and whether its protocol
  // has the choice at all. "" is vendor detection, which is what an endpoint
  // nobody has characterised keeps doing.
  canSetContinuation?: boolean;
  continuation?: string;
  // Which request shape this endpoint controls thinking with, as declared.
  // Absent is "nobody said", which is why a relay's effort ladder comes out
  // empty — nothing can be probed for it.
  reasoningProtocol?: string;
  // A declared effort vocabulary, which replaces the protocol's ladder, and the
  // level auto resolves to. Absent is no declaration.
  supportedEfforts?: string[];
  defaultEffort?: string;
  // Per model, for a relay serving several vendors under one key: what a model
  // declares for itself, the ladder it inherits when it declares nothing, and
  // a reasoning protocol it declares for itself.
  modelEfforts?: Record<string, ModelEffort>;
  inheritedEfforts?: Record<string, ModelEffort>;
  modelProtocols?: Record<string, string>;
  // Per model: the window and output cap it declares for itself, and the ones
  // it inherits when it declares none.
  modelLimits?: Record<string, ModelLimit>;
  inheritedLimits?: Record<string, ModelLimit>;
  // Per model: the price per million tokens it declares for itself. A model
  // with none is absent, which means unknown, not zero.
  modelPrices?: Record<string, ModelRate>;
  // payg, or subscription_equivalent where the figures are an API-priced estimate
  // of a plan rather than what is billed.
  billingMode?: string;
  // A vendor's own endpoint: its table can say whether a stored price is its own.
  officialPricing?: boolean;
  // How the latest plain test of this saved entry ended, in this kernel process.
  // Absent when none ran or the entry changed since.
  lastCheck?: { at: number; ok: boolean; code?: string };
  // Removing the one in use would leave the session on a model that no longer
  // resolves, so the row offers no delete.
  inUse: boolean;
  preset: boolean;
  // The three no probe can answer: the window is a fact about the model that
  // endpoints do not report, and headers / extra body are what a relay demands
  // on top of the protocol.
  contextWindow?: number;
  maxOutputTokens?: number;
  // Seconds the endpoint may stay silent before the call is read as dropped;
  // absent is the built-in default.
  idleTimeoutSeconds?: number;
  // What a source without one waits; the kernel owns the number.
  idleTimeoutDefault?: number;
  // The wallet endpoint and the format its answer is read in. impliedBalanceFormat
  // is what the saved address's own host implies when none is declared, empty for
  // a relay, which must declare one; balanceFormats is the closed set to offer.
  balanceUrl?: string;
  balanceFormat?: string;
  impliedBalanceFormat?: string;
  balanceFormats?: string[];
  headers?: Record<string, string>;
  extraBody?: Record<string, unknown>;
}

// One wire format a source may be saved as, as the kernel declares it. The
// list is the kernel's and the words for it are ours: no label rides along.
export interface Protocol {
  kind: string;
  // What a model on this wire produces. A decision wire returns verdicts to a
  // question set and holds no conversation, so it is offered for the decision
  // role and nowhere else. Absent means chat: it is what every wire was before
  // decision backends, and a kernel that predates the field still answers.
  answers?: "chat" | "decision";
  // Which model-listing shape this wire is discovered under. Protocols sharing
  // one value answer the same listing and cannot be told apart by a probe.
  discovery: string;
  // Whether the wire has a format for a provider-executed web search tool, and
  // whether thinking/effort fields ride it at all.
  serverWebSearch: boolean;
  reasoningParams: boolean;
  effortField?: string;
  // The reasoning protocols under which that field holds; empty when the wire
  // fixes it whatever protocol is chosen.
  effortUnder?: string[];
}

// A curated starting point the kernel offers. Choosing one creates the whole
// declared entry — catalog, window, vision models, thinking shape — in the
// kernel; the person supplies only a name and a key.
export interface ProviderPreset {
  id: string;
  label: string;
  kind: string;
  baseUrl: string;
  // Who makes or runs the service, declared by the kernel's catalogue. The mark
  // drawn for it is keyed on this, never on the label.
  vendor: string;
}

export interface ProviderPresetInstall {
  presetId: string;
  // Empty takes the preset's own name, made unique by the kernel.
  name?: string;
  apiKey: string;
}

// What an endpoint turned out to be. Every field is a guess the user confirms
// before anything is written — a model list cannot prove which protocol a
// gateway speaks, only which ones it answers.
export interface ProviderProbe {
  kind: string;
  // The address chat must be rooted at: what was typed, completed with /v1 only
  // when the model list answered there alone.
  baseUrl?: string;
  // Every kind that listing may be driven with, kernel order. `kind` is the
  // pre-selection among them, not the only answer: DeepSeek serves both the
  // OpenAI chat wire and the Responses API off one model list.
  kinds: string[];
  authHeader: boolean;
  models: string[];
  default: string;
  efforts: string[];
  effort: string;
  vision: string[];
  // ambiguous: more than one protocol answered, so the kind is a preference
  // rather than a finding.
  ambiguous: boolean;
  // noProxy: it answered only with the proxy bypassed (a China-only endpoint
  // behind a foreign exit resets the handshake).
  noProxy: boolean;
}

// What re-probing a saved provider found. A failure carries `code`, the dotted
// identity the add flow's refusals use, because "401" and "no chat models" send
// the user to different fixes; the endpoint's own words ride along as `detail`.
export interface ProviderRemoval {
  movedTo: string;
  moved: string[];
  cleared: string[];
}

/** The form's unsaved state, laid over the saved entry for one check. Blank
 *  means what is saved. Nothing in it is written anywhere. */
export interface ProviderCheckDraft {
  baseUrl?: string;
  apiKey?: string;
  kind?: string;
}

export interface ProviderCheck {
  ok: boolean;
  kind?: string;
  // Present only when the saved address is not the one chat needs.
  baseUrl?: string;
  // Whether that answer is consistent with the kind the entry records. A
  // Responses source answers the OpenAI listing, so equality is the wrong test.
  matches?: boolean;
  models?: string[];
  // Re-probing is also capability discovery: a vendor may add a multimodal
  // model to an endpoint whose stored model list predates it.
  vision?: string[];
  ambiguous?: boolean;
  noProxy?: boolean;
  code?: string;
  // The host a refused redirect pointed at.
  target?: string;
  // Only the numbers the code's sentence needs: `status`, `count`.
  params?: Record<string, number>;
  httpStatus?: number;
  // The endpoint's error text, for display; never an input to `code`.
  detail?: string;
}

export type ProviderModelCheckStatus = "available" | "unavailable" | "unknown";
export type ProviderModelCheckReason =
  | "auth"
  | "not_found"
  | "rate_limited"
  | "rejected"
  | "network"
  | "timeout"
  // Timed out against the machine's own address: the engine did not answer, not the network.
  | "local_timeout"
  // The address redirected to another host; the detail names it.
  | "redirect_refused"
  // The endpoint answered chat and refused a tools array. Established by
  // sending the same request again without one, not by reading the refusal.
  | "tools";

// A deliberate, billable check of one exact model id. Listing and calling are
// separate facts: private models often accept requests without appearing in a catalog.
export interface ProviderModelCheck {
  model: string;
  status: ProviderModelCheckStatus;
  reason?: ProviderModelCheckReason;
  httpStatus?: number;
  // The endpoint's own error text, for display; never an input to status or reason.
  detail?: string;
}

export interface ProviderModelCheckRequest {
  name?: string;
  model: string;
  baseUrl?: string;
  apiKey?: string;
  kind?: string;
  authHeader?: boolean;
  noProxy?: boolean;
}

// Changing a source that already exists: everything else on the entry stays.
export interface ProviderEdit {
  name: string;
  // Omitted preserves aliases; blank or missing values reset listed models.
  modelAliases?: Record<string, string>;
  // Omitted leaves the choice alone.
  hideModelPrefix?: boolean;
  // Omitted leaves the wire format alone.
  kind?: string;
  baseUrl?: string;
  // Empty keeps the stored key.
  apiKey?: string;
  models: string[];
  default: string;
  vision: string[];
  // Omitted means "leave it alone" — sending an empty object instead would
  // clear headers a gateway needs. 0 is a real window: it turns automatic
  // compaction off for this source.
  contextWindow?: number;
  maxOutputTokens?: number;
  // 0 is the built-in default; omitted leaves the stored value alone.
  idleTimeoutSeconds?: number;
  // The wallet endpoint and its format; omitted leaves them alone, an empty
  // address removes the readout and its format.
  balanceUrl?: string;
  balanceFormat?: string;
  headers?: Record<string, string>;
  extraBody?: Record<string, unknown>;
  // Which request shape controls thinking here. "" is auto — no declaration,
  // which leaves the registry in charge. Omitted still means "leave it alone".
  reasoningProtocol?: string;
  // Whether to use the endpoint-executed search tool, and how context reaches
  // the next turn ("" is auto). Omitted leaves the stored choice alone.
  webSearch?: boolean;
  continuation?: string;
  // An empty list clears the declared vocabulary; omitted leaves it alone.
  supportedEfforts?: string[];
  defaultEffort?: string;
  // The whole per-model answer for the listed models: a model left out
  // inherits the connection's levels again. Omitted leaves every model alone.
  modelEfforts?: Record<string, ModelEffort>;
  // The whole per-model answer for the listed models: a model left out, or sent
  // empty, inherits the connection's limits again. Omitted leaves every model alone.
  modelLimits?: Record<string, ModelLimit>;
  // The whole per-model answer for the listed models: a model sent null has no
  // price of its own again. Omitted leaves every model alone.
  modelPrices?: Record<string, ModelRate | null>;
  // payg or subscription_equivalent; omitted leaves the stored mode alone.
  billingMode?: string;
}

// One model's price per million tokens, zeros included: free is a price.
export interface ModelRate {
  input: number;
  output: number;
  cacheHit: number;
  currency: string;
  // Where the price was read and on what UTC date (YYYY-MM-DD). They describe the
  // price and take no part in quoting it.
  sourceUrl?: string;
  checked?: string;
  // True when the card is one the vendor's table has; sent by the kernel, never back.
  official?: boolean;
}

// One model's own context window and output cap; an absent field inherits.
export interface ModelLimit {
  contextWindow?: number;
  maxOutputTokens?: number;
}

// One model's effort vocabulary and the level auto resolves to; no default is
// the first level.
export interface ModelEffort {
  supportedEfforts: string[];
  defaultEffort?: string;
  // On an inherited ladder: the vendor's documented contract, not typed levels.
  official?: boolean;
}

// What the panel sends back after the user has looked at the probe.
export interface ProviderDraft {
  name: string;
  kind: string;
  baseUrl: string;
  apiKey: string;
  models: string[];
  default: string;
  authHeader: boolean;
  noProxy: boolean;
  effort: string;
  vision: string[];
  contextWindow?: number;
  maxOutputTokens?: number;
  // Optional endpoint compatibility. Omitted values keep the kernel's
  // protocol defaults; they live behind the advanced disclosure in the UI.
  reasoningProtocol?: string;
  headers?: Record<string, string>;
  extraBody?: Record<string, unknown>;
  // Saving under a name already configured is refused unless this is set.
  replace?: boolean;
}

// What the opening sequence still owes a machine with no usable key. GET
// /provider-setup 404s once one exists, so null means "ready".
export interface ProviderSetup {
  required: boolean;
  // The runtime started with no provider at all: there is no model whose key could be missing.
  noProvider?: boolean;
  provider?: string;
  model?: string;
  modelRef?: string;
  keyEnv?: string;
  error?: string;
  activationPending?: boolean;
}
