import { HttpError } from "./http_error";
import { MockCommit } from "./mock_commit";
import { FEEDBACK_CODE, canWithdraw, type FeedbackBoard, type FeedbackBoardEntry, type FeedbackBoardMe, type FeedbackEnv, type FeedbackImage, type FeedbackItem, type FeedbackLinkedInstall, type FeedbackMine, type FeedbackProfile, type FeedbackReceipt, type FeedbackReply, type FeedbackReplyReceipt, type FeedbackRequest } from "./feedback";

const LIMITS = { bodyBytes: 8192, nameChars: 40, contactChars: 120, images: 3, imageBytes: 2 << 20, uploadBytes: 10 << 20, replyBytes: 4096 };

const ENV = {
  version: "v2.24.0", commit: "7ee4bbb", surface: "studio", os: "windows", osVersion: "10.0.19045",
  arch: "amd64", locale: "en-US", channel: "stable", providerKind: "deepseek",
  memory: [{ process: "kernel" as const, workingSetKB: 196608, privateKB: 150000 }],
};

const DAY = 86_400_000;
const ago = (days: number) => new Date(Date.now() - days * DAY).toISOString();

const item = (over: Partial<FeedbackItem> & Pick<FeedbackItem, "receipt" | "category" | "titleSnippet" | "status" | "createdAt" | "updatedAt">): FeedbackItem => ({
  needsInput: false, underReview: false, replies: [], unreadReplies: 0, ...over,
});

const msg = (id: number, author: FeedbackReply["author"], body: string, days: number): FeedbackReply => ({ id, author, body, createdAt: ago(days) });

// One row per status, so the list is never drawn from a fixture that skips one.
const SEEDED: FeedbackItem[] = [
  item({ receipt: "FB-7K3M-9QX2", category: "bug", titleSnippet: "Sidebar loses its selection after a resize", status: "fixed", issueNumber: 11350, issueUrl: "https://github.com/esengine/DeepSeek-Reasonix/issues/11350", resolvedVersion: "v2.21.0", createdAt: ago(6), updatedAt: ago(1) }),
  item({ receipt: "FB-2H8P-4WD7", category: "idea", titleSnippet: "Export a session as markdown", status: "recorded", issueNumber: 11302, issueUrl: "https://github.com/esengine/DeepSeek-Reasonix/issues/11302", createdAt: ago(4), updatedAt: ago(3) }),
  item({ receipt: "FB-5N1C-8RT3", category: "bug", titleSnippet: "Paste of a long log freezes the composer", status: "in_progress", issueNumber: 11377, issueUrl: "https://github.com/esengine/DeepSeek-Reasonix/issues/11377", createdAt: ago(3), updatedAt: ago(1),
    replies: [msg(21, "maintainer", "Thanks, reproduced. Does it also freeze with a 2 MB log, or only with the 40 MB one?", 2), msg(22, "user", "Only the 40 MB one. The 2 MB log pastes fine.", 1.5)] }),
  item({ receipt: "FB-9B4D-1XM6", category: "question", titleSnippet: "Where do I change the default model?", status: "received", createdAt: ago(0.1), updatedAt: ago(0.1) }),
  item({ receipt: "FB-3F6G-2KV9", category: "idea", titleSnippet: "Fixed in the next build: quieter update banner", status: "fixed", issueNumber: 11390, issueUrl: "https://github.com/esengine/DeepSeek-Reasonix/issues/11390", resolvedVersion: "next", createdAt: ago(8), updatedAt: ago(0.5) }),
  item({ receipt: "FB-8Q2J-6PW4", category: "other", titleSnippet: "Please support a monorepo layout", status: "wontfix", issueNumber: 11288, issueUrl: "https://github.com/esengine/DeepSeek-Reasonix/issues/11288", createdAt: ago(12), updatedAt: ago(5) }),
  item({ receipt: "FB-4T7V-3ZH1", category: "bug", titleSnippet: "Crash when opening settings on a small window", status: "duplicate", issueNumber: 11301, issueUrl: "https://github.com/esengine/DeepSeek-Reasonix/issues/11301", duplicateOf: 11299, createdAt: ago(15), updatedAt: ago(9) }),
  item({ receipt: "FB-2D8K-4HQ6", category: "idea", titleSnippet: "Sent by mistake, please ignore", status: "withdrawn", createdAt: ago(6), updatedAt: ago(5.5) }),
  item({ receipt: "FB-7L3Q-2DM8", category: "idea", titleSnippet: "Filed from my other laptop: a calmer sidebar", status: "recorded", issueNumber: 11402, issueUrl: "https://github.com/esengine/DeepSeek-Reasonix/issues/11402", otherInstall: true, createdAt: ago(3), updatedAt: ago(2) }),
  item({ receipt: "FB-5R2T-6VB3", category: "bug", titleSnippet: "Settings sheet flickers when the window is dragged", status: "received", underReview: true, createdAt: ago(0.3), updatedAt: ago(0.3) }),
  item({ receipt: "FB-6M9R-5CE8", category: "question", titleSnippet: "How do I move my sessions to another disk?", status: "received", statusUnavailable: true, createdAt: ago(40), updatedAt: ago(40) }),
  item({ receipt: "FB-1C5W-7NB2", category: "bug", titleSnippet: "Terminal output is cut off after a resize", status: "needs_info", needsInput: true, createdAt: ago(2), updatedAt: ago(0.2),
    replies: [msg(31, "maintainer", "Thanks for the report. Which operating system and which shell are you using?\nAnd can you say what the window size was before you resized it?", 0.2)] }),
  item({ receipt: "FB-8D3X-4LP6", category: "question", titleSnippet: "Can I use two providers at once?", status: "answered", createdAt: ago(5), updatedAt: ago(4),
    replies: [msg(11, "maintainer", "Yes: add both under Settings > Model services and pick one per session from the model menu.", 4)] }),
  item({ receipt: "FB-2Z6Q-8HK5", category: "other", titleSnippet: "Unrelated advertisement text", status: "closed", createdAt: ago(7), updatedAt: ago(7) }),
];

// A tab's own sessionStorage picks the refusal the next call answers with, so a
// dev page can show every failure without a kernel that will produce it.
const FAULT = "rx-mock-feedback-fault";
const REPLY_FAULT = "rx-mock-feedback-reply-fault";
const LATE_REPLY = "rx-mock-feedback-late-reply";

function fault(key = FAULT): string {
  try {
    return sessionStorage.getItem(key) ?? "";
  } catch {
    return "";
  }
}

// A tab's own sessionStorage also picks the standing the list answers with, for
// the same reason: "l0".."l6", "legacy", "lapsed", "revoked", or "none" for a
// service that states no profile.
const STANDING = "rx-mock-feedback-standing";
const PROMOTION = "rx-mock-feedback-promotion";

const THRESHOLDS = [0, 1, 3, 6, 12, 24, 48];
const LEVEL_LIMITS = [[3, 10, 3], [5, 15, 4], [6, 20, 5], [8, 25, 6], [10, 30, 8], [12, 40, 10], [12, 60, 10]] as const;
const BASE_LIMITS = LEVEL_LIMITS[0];
const TRUSTED_LIMITS = LEVEL_LIMITS[6];

function standing(kind: string): FeedbackProfile | null {
  if (kind === "none") return null;
  const level = /^l[0-6]$/.test(kind) ? Number(kind.slice(1)) : kind === "lapsed" ? 3 : kind === "revoked" ? 2 : kind === "legacy" ? 0 : 2;
  const adopted = kind === "legacy" ? 0 : THRESHOLDS[level]! + (level === 6 ? 2 : level === 0 ? 0 : 1);
  const next = THRESHOLDS[level + 1];
  const state = kind === "lapsed" ? "lapsed" : kind === "revoked" ? "revoked" : kind === "legacy" ? "legacy_active" : level === 0 ? "none" : "active";
  const [h, d, r] = state === "lapsed" || state === "revoked" || state === "none" ? BASE_LIMITS : state === "legacy_active" ? TRUSTED_LIMITS : LEVEL_LIMITS[level]!;
  return {
    level, adoptedCount: adopted, currentThreshold: THRESHOLDS[level]!,
    nextLevel: next === undefined ? null : level + 1, nextThreshold: next ?? null, remaining: next === undefined ? null : next - adopted,
    trustState: state, trustExpiresAt: state === "active" || state === "legacy_active" ? new Date(Date.now() + 20 * DAY).toISOString() : null,
    observedAt: new Date().toISOString(), effectiveLimits: { reportsPerHour: h, reportsPerDay: d, repliesPerHour: r },
  };
}

const STATUS: Record<string, number> = {
  [FEEDBACK_CODE.tooLarge]: 413, [FEEDBACK_CODE.rateLimited]: 429, [FEEDBACK_CODE.disabled]: 503,
  [FEEDBACK_CODE.duplicate]: 409, [FEEDBACK_CODE.badToken]: 409, [FEEDBACK_CODE.offline]: 502, [FEEDBACK_CODE.unavailable]: 502, [FEEDBACK_CODE.internal]: 500, [FEEDBACK_CODE.busy]: 503, [FEEDBACK_CODE.imageMetadata]: 400,
  [FEEDBACK_CODE.replyLimit]: 429, [FEEDBACK_CODE.notReplyable]: 409, [FEEDBACK_CODE.challengeRequired]: 403,
  [FEEDBACK_CODE.accountRequired]: 401, [FEEDBACK_CODE.linkConflict]: 409, [FEEDBACK_CODE.linkLimit]: 409, [FEEDBACK_CODE.noInstall]: 409,
};

// A fault is a code, optionally followed by "@" and the window it names:
// "feedback.rate_limited@install_daily".
function refusal(fault: string): HttpError {
  const [code = "", limit] = fault.split("@");
  const soon = new Date(Date.now() + (limit === "install_daily" ? 5 * 3_600_000 : 25 * 60_000)).toISOString();
  let params: Record<string, string | number> = code === FEEDBACK_CODE.rateLimited ? { retryAfterSeconds: 90 } : {};
  if (limit === "reply_item") params = { limit };
  else if (limit) params = { limit, resetsAt: soon, retryAfterSeconds: Math.round((Date.parse(soon) - Date.now()) / 1000) };
  return new HttpError(STATUS[code] ?? 500, code, { code, error: code, params });
}

export class MockFeedback extends MockCommit {
  private filed: FeedbackItem[] = [];
  private name = "";
  private rows: FeedbackItem[] = SEEDED.map((i) => ({ ...i, replies: [...i.replies] }));
  private seen = new Map<string, number>();

  async feedbackEnv(): Promise<FeedbackEnv> {
    return { env: ENV, displayName: this.name, limits: LIMITS };
  }

  async sendFeedback(req: FeedbackRequest): Promise<FeedbackReceipt> {
    const code = fault();
    if (code === "feedback.invalid") {
      throw new HttpError(400, "invalid", { code, error: "invalid", params: { field: "body", reason: "too_long" } });
    }
    if (code && STATUS[code.split("@")[0]!]) throw refusal(code);
    this.name = req.displayName;
    const receipt = "FB-" + (1000 + this.filed.length * 7).toString(36).toUpperCase().padStart(4, "K") + "-9QX2";
    const now = new Date().toISOString();
    this.filed = [item({ receipt, category: req.category, titleSnippet: req.body.trim().slice(0, 80), status: "received", createdAt: now, updatedAt: now }), ...this.filed];
    return { receipt, status: "received", createdAt: now, underReview: false, redacted: /sk-[A-Za-z0-9]{8,}/.test(req.body) };
  }

  async myFeedback(): Promise<FeedbackMine> {
    const code = fault();
    if (code === "mine_error") throw new HttpError(502, "unavailable", { code: FEEDBACK_CODE.unavailable, error: "unavailable" });
    const late = fault(LATE_REPLY) !== "";
    const items = [...this.filed, ...this.rows].map((row) => {
      const i = late && row.receipt === "FB-9B4D-1XM6" ? { ...row, replies: [msg(41, "maintainer", "Settings > Model services.", 0)] } : row;
      const unreadReplies = i.replies.filter((r) => r.author === "maintainer" && r.id > (this.seen.get(i.receipt) ?? 0)).length;
      return { ...i, needsInput: i.statusUnavailable ? false : i.needsInput, unreadReplies };
    });
    const unread = items.filter((i) => i.unreadReplies > 0 || i.needsInput).length;
    return { items, offline: code === "mine_offline", unread, hasNew: unread > 0, profile: standing(fault(STANDING)), promotion: this.promotion() };
  }

  // A tab's own sessionStorage ("2:3") stages a level-up for a dev page, until it is acknowledged.
  private promotion(): { from: number; to: number } | null {
    const [from, to] = fault(PROMOTION).split(":").map(Number);
    return Number.isInteger(from) && Number.isInteger(to) && to > from && !this.acked.has(to) ? { from, to } : null;
  }

  private acked = new Set<number>();

  async ackFeedbackPromotion(level: number): Promise<void> {
    this.acked.add(level);
  }

  announced = 0;

  async announceFeedbackReply(): Promise<void> {
    this.announced += 1;
  }

  readonly replyImages: number[] = [];

  async replyFeedback(receipt: string, body: string, images: FeedbackImage[] = []): Promise<FeedbackReplyReceipt> {
    this.replyImages.push(images.length);
    const code = fault(REPLY_FAULT);
    if (code === "feedback.invalid") {
      throw new HttpError(400, "invalid", { code, error: "invalid", params: { field: "body", reason: "empty" } });
    }
    if (code) throw refusal(code);
    const row = this.rows.find((i) => i.receipt === receipt);
    if (!row) throw refusal(FEEDBACK_CODE.notReplyable);
    this.seen.set(receipt, Math.max(0, ...row.replies.map((r) => r.id)));
    const replyId = Math.max(0, ...row.replies.map((r) => r.id)) + 1;
    const createdAt = new Date().toISOString();
    row.replies.push({ id: replyId, author: "user", body, createdAt });
    row.updatedAt = createdAt;
    row.needsInput = false;
    if (row.status === "needs_info") row.status = "received";
    return { replyId, createdAt };
  }

  // The demo keeps its links in the tab: signed-in is the same switch account() reads.
  private links: FeedbackLinkedInstall[] = [{ id: "ba9876543210", linkedAt: ago(9), current: false }];

  private requireAccount(): void {
    if (!localStorage.getItem("reasonix.mock.account")) throw refusal(FEEDBACK_CODE.accountRequired);
  }

  async feedbackLinks(): Promise<FeedbackLinkedInstall[]> {
    this.requireAccount();
    return this.links.map((l) => ({ ...l }));
  }

  async linkFeedbackAccount(): Promise<void> {
    this.requireAccount();
    if (!this.links.some((l) => l.current)) this.links = [...this.links, { id: "0123456789ab", linkedAt: new Date().toISOString(), current: true }];
  }

  async unlinkFeedbackAccount(): Promise<void> {
    this.requireAccount();
    this.links = this.links.filter((l) => !l.current);
  }

  // The demo board: a handful of people, credits spread over three releases.
  private board: FeedbackBoardEntry[] = [
    { displayName: "Sample Alpha", credits: 7, rank: null, releases: [{ version: "v2.45.0", count: 3 }, { version: "v2.44.0", count: 2 }, { version: "v2.43.0", count: 2 }] },
    { displayName: "示例用户", credits: 5, rank: null, releases: [{ version: "v2.45.0", count: 2 }, { version: "v2.44.0", count: 3 }] },
    { displayName: "sample_beta", credits: 3, rank: null, releases: [{ version: "v2.45.0", count: 2 }, { version: "v2.43.0", count: 1 }] },
    { displayName: "Sample-Gamma", credits: 2, rank: null, releases: [{ version: "v2.44.0", count: 1 }, { version: "v2.43.0", count: 1 }] },
    { displayName: "Sample Delta", credits: 1, rank: null, releases: [{ version: "v2.45.0", count: 1 }] },
  ];
  private chosen: string | null = null;

  private boardMe(): FeedbackBoardMe {
    return { listed: this.chosen !== null, displayName: this.chosen, delisted: false };
  }

  async feedbackBoard(release?: string): Promise<FeedbackBoard> {
    if (!release) {
      const all = [...this.board].sort((a, b) => a.displayName.localeCompare(b.displayName));
      return { available: true, view: "all", release: null, entries: all };
    }
    const rows = this.board
      .map((e) => ({ ...e, releases: e.releases.filter((r) => r.version === release) }))
      .filter((e) => e.releases.length > 0)
      .map((e) => ({ ...e, credits: e.releases.reduce((n, r) => n + r.count, 0) }))
      .sort((a, b) => b.credits - a.credits || a.displayName.localeCompare(b.displayName));
    let rank = 0;
    const entries = rows.map((e, i) => {
      if (i === 0 || e.credits !== rows[i - 1].credits) rank = i + 1;
      return { ...e, rank };
    });
    return { available: true, view: "release", release, entries };
  }

  async feedbackBoardMe(): Promise<FeedbackBoardMe> {
    this.requireAccount();
    return this.boardMe();
  }

  async joinFeedbackBoard(displayName: string): Promise<FeedbackBoardMe> {
    this.requireAccount();
    this.chosen = displayName.trim();
    return this.boardMe();
  }

  async leaveFeedbackBoard(): Promise<FeedbackBoardMe> {
    this.requireAccount();
    this.chosen = null;
    return this.boardMe();
  }

  async unlinkFeedbackInstall(id: string): Promise<void> {
    this.requireAccount();
    this.links = this.links.filter((l) => l.id !== id);
  }

  async withdrawFeedback(receipt: string): Promise<void> {
    const row = this.rows.find((i) => i.receipt === receipt);
    if (!row) throw refusal(FEEDBACK_CODE.notFound);
    if (!canWithdraw(row)) throw refusal(FEEDBACK_CODE.notWithdrawable);
    row.status = "withdrawn";
    row.needsInput = false;
    row.updatedAt = new Date().toISOString();
  }

  async feedbackSeen(receipt: string, upTo: number): Promise<void> {
    if (this.rows.some((i) => i.receipt === receipt)) this.seen.set(receipt, Math.max(this.seen.get(receipt) ?? 0, upTo));
  }
}
